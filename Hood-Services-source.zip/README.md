# Hood Services (Axlehouse)

Fleet / service-yard management app for trucks, tires, oil changes, and fees.

Built with **TanStack Start** + Vite + React + Tailwind + local PGlite / Better Auth.

## Features

- **Yard** overview – spots, spend, and what’s due
- **Trucks** – numbers, VINs, plates, engines
- **Tires** – usage tracking and tire fees
- **Oil** – change logs and intervals
- **Fees** – unified ledger of charges
- Backup / restore as JSON
- Sample data loader

## Quick start

```bash
npm install
npm run dev
```

App runs at http://localhost:8080

## Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Start development server |
| `npm run build` | Production build + DB migrate |
| `npm run typecheck` | TypeScript check |
| `npm test` | Run tests |

## Deploy

This project is set up for Vercel (`vercel.json` included).

```bash
npx vercel
```

## Notes

- Data is stored client-side (local persistence) with optional server auth/DB pieces from the Grok App Builder template.
- The original workspace zip is still in the repo history if needed.
