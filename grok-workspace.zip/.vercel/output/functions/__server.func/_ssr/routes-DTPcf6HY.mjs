import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Search, c as Droplet, d as ChevronDown, l as Download, n as Upload, o as Receipt, r as Truck, s as LayoutGrid, t as X, u as CircleDot } from "../_libs/lucide-react.mjs";
import { a as differenceInCalendarDays, i as startOfMonth, n as parseISO, r as format, t as subMonths } from "../_libs/date-fns.mjs";
import { a as DialogOverlay, i as DialogDescription, l as Slot, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DTPcf6HY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function money(n) {
	return new Intl.NumberFormat("en-US", {
		style: "currency",
		currency: "USD"
	}).format(n);
}
function miles(n) {
	return `${new Intl.NumberFormat("en-US").format(Math.round(n))} mi`;
}
function shortDate(iso) {
	if (!iso) return "—";
	const d = parseISO(iso);
	if (Number.isNaN(d.getTime())) return iso;
	return format(d, "MMM d, yyyy");
}
function todayISO() {
	const d = /* @__PURE__ */ new Date();
	const m = String(d.getMonth() + 1).padStart(2, "0");
	const day = String(d.getDate()).padStart(2, "0");
	return `${d.getFullYear()}-${m}-${day}`;
}
function addDaysISO(days, from = todayISO()) {
	const d = parseISO(from);
	d.setDate(d.getDate() + days);
	const m = String(d.getMonth() + 1).padStart(2, "0");
	const day = String(d.getDate()).padStart(2, "0");
	return `${d.getFullYear()}-${m}-${day}`;
}
function parseMoney(value) {
	const n = Number(value.replace(/[$,\s]/g, ""));
	return Number.isFinite(n) ? Math.round(n * 100) / 100 : null;
}
function parseMiles(value) {
	const n = Number(value.replace(/[,\s]/g, ""));
	return Number.isFinite(n) ? Math.round(n) : null;
}
function SpendChart({ data }) {
	const [Inner, setInner] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let live = true;
		import("./spend-chart-inner-D3mbx6yT.mjs").then((mod) => {
			if (live) setInner(() => mod.SpendChartInner);
		});
		return () => {
			live = false;
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [Inner ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inner, { data }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-52 rounded-md bg-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 flex gap-4 text-xs text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "inline-flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-sm bg-primary" }), "Tires"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "inline-flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-sm bg-muted-foreground" }), "Oil"]
		})]
	})] });
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40 disabled:pointer-events-none disabled:opacity-50", {
	variants: {
		variant: {
			primary: "bg-primary text-primary-foreground hover:bg-primary/90",
			secondary: "border border-border bg-card text-foreground hover:bg-muted",
			ghost: "bg-transparent text-foreground hover:bg-muted",
			danger: "bg-destructive text-primary-foreground hover:bg-destructive/90"
		},
		size: {
			md: "h-11 px-4",
			sm: "h-9 px-3",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild, type, ...props }) {
	if (asChild) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slot, {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: type ?? "button",
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function bySpot(a, b) {
	return a.spot.localeCompare(b.spot, void 0, {
		numeric: true,
		sensitivity: "base"
	});
}
function byNumber(a, b) {
	return a.number.localeCompare(b.number, void 0, {
		numeric: true,
		sensitivity: "base"
	});
}
function truckLabel(truck) {
	return truck ? `Truck ${truck.number}` : "Unknown truck";
}
function unitLine(truck) {
	return [
		truck.year,
		truck.make,
		truck.model
	].filter(Boolean).join(" ");
}
function engineLine(truck) {
	return [truck.engineSize, truck.engineDetails].filter(Boolean).join(" · ");
}
function haystack(parts) {
	return parts.join(" ").toLowerCase();
}
function includesQuery(hay, query) {
	const q = query.trim().toLowerCase();
	if (!q) return true;
	return hay.includes(q);
}
function truckHay(truck) {
	return haystack([
		truck.number,
		`truck ${truck.number}`,
		truck.vin,
		truck.plate,
		truck.spot,
		`spot ${truck.spot}`,
		truck.year,
		truck.make,
		truck.model,
		truck.engineSize,
		truck.engineDetails,
		truck.notes,
		truck.status
	]);
}
function latestOil(oils, truckId) {
	return oils.filter((o) => o.truckId === truckId).sort((a, b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id))[0];
}
function oilStatus(truck, oils, today = /* @__PURE__ */ new Date()) {
	const latest = latestOil(oils, truck.id);
	if (!latest) return {
		tone: "warn",
		label: "No oil record",
		detail: "Log the last change"
	};
	const milesLeft = latest.nextDueMileage > 0 ? latest.nextDueMileage - truck.odometer : null;
	let daysLeft = null;
	if (latest.nextDueDate) {
		const due = parseISO(latest.nextDueDate);
		if (!Number.isNaN(due.getTime())) daysLeft = differenceInCalendarDays(due, today);
	}
	const parts = [];
	if (milesLeft !== null) parts.push(milesLeft >= 0 ? `${miles(milesLeft)} left` : `${miles(Math.abs(milesLeft))} past`);
	if (latest.nextDueDate) parts.push(daysLeft !== null && daysLeft < 0 ? `was due ${shortDate(latest.nextDueDate)}` : `due ${shortDate(latest.nextDueDate)}`);
	const detail = parts.join(" · ");
	const mileBad = milesLeft !== null && milesLeft <= 0;
	const dateBad = daysLeft !== null && daysLeft < 0;
	const mileSoon = milesLeft !== null && milesLeft > 0 && milesLeft <= 2e3;
	const dateSoon = daysLeft !== null && daysLeft >= 0 && daysLeft <= 21;
	if (mileBad || dateBad) return {
		tone: "bad",
		label: "Overdue",
		detail
	};
	if (mileSoon || dateSoon) return {
		tone: "warn",
		label: "Due soon",
		detail
	};
	return {
		tone: "good",
		label: "On schedule",
		detail
	};
}
function attentionRank(tone) {
	if (tone === "bad") return 0;
	if (tone === "warn") return 1;
	return 2;
}
function sharedSpotIds(trucks) {
	const groups = /* @__PURE__ */ new Map();
	for (const truck of trucks) {
		const key = truck.spot.trim().toLowerCase();
		if (!key) continue;
		const list = groups.get(key) ?? [];
		list.push(truck.id);
		groups.set(key, list);
	}
	const shared = /* @__PURE__ */ new Set();
	for (const ids of groups.values()) if (ids.length > 1) ids.forEach((id) => shared.add(id));
	return shared;
}
function sumInYear(tires, oils, year) {
	const prefix = `${year}-`;
	const tire = tires.filter((t) => t.date.startsWith(prefix)).reduce((sum, t) => sum + t.fee, 0);
	const oil = oils.filter((o) => o.date.startsWith(prefix)).reduce((sum, o) => sum + o.fee, 0);
	return {
		tire,
		oil,
		total: tire + oil
	};
}
function spendForTruck(tires, oils, truckId) {
	const tire = tires.filter((t) => t.truckId === truckId).reduce((sum, t) => sum + t.fee, 0);
	const oil = oils.filter((o) => o.truckId === truckId).reduce((sum, o) => sum + o.fee, 0);
	return {
		tire,
		oil,
		total: tire + oil
	};
}
function monthlySpend(tires, oils, count = 6, from = /* @__PURE__ */ new Date()) {
	const start = startOfMonth(from);
	const points = [];
	for (let i = count - 1; i >= 0; i -= 1) {
		const d = subMonths(start, i);
		const key = format(d, "yyyy-MM");
		points.push({
			key,
			label: format(d, "MMM"),
			tires: tires.filter((t) => t.date.startsWith(key)).reduce((sum, t) => sum + t.fee, 0),
			oil: oils.filter((o) => o.date.startsWith(key)).reduce((sum, o) => sum + o.fee, 0)
		});
	}
	return points;
}
function tireDetail(event) {
	const spec = [event.brand, event.size].filter(Boolean).join(" ");
	return [
		event.action,
		event.position,
		spec
	].filter(Boolean).join(" · ");
}
function oilDetail(event) {
	return [
		event.oilType,
		event.quantity,
		event.vendor
	].filter(Boolean).join(" · ");
}
function iso(daysFromToday) {
	const d = /* @__PURE__ */ new Date();
	d.setHours(12, 0, 0, 0);
	d.setDate(d.getDate() + daysFromToday);
	const m = String(d.getMonth() + 1).padStart(2, "0");
	const day = String(d.getDate()).padStart(2, "0");
	return `${d.getFullYear()}-${m}-${day}`;
}
var seedTrucks = [
	{
		id: "t214",
		number: "214",
		vin: "1FUJGLDR5PLNA4821",
		plate: "NL-2148",
		spot: "12",
		year: "2023",
		make: "Freightliner",
		model: "Cascadia",
		engineSize: "15.0 L",
		engineDetails: "Cummins X15 Efficiency, 450 hp, 1,850 lb-ft",
		odometer: 412880,
		status: "in-service",
		notes: "APU on the sleeper. Steer alignment checked last month."
	},
	{
		id: "t187",
		number: "187",
		vin: "3AKJHHDR8NSMN2290",
		plate: "NL-1872",
		spot: "4",
		year: "2022",
		make: "Kenworth",
		model: "T680",
		engineSize: "12.8 L",
		engineDetails: "Detroit DD13, 470 hp, 1,650 lb-ft",
		odometer: 388120,
		status: "shop",
		notes: "In the shop for a turbo actuator. Do not dispatch."
	},
	{
		id: "t301",
		number: "301",
		vin: "1XKYD49X4NJ456812",
		plate: "NL-3016",
		spot: "18",
		year: "2024",
		make: "Peterbilt",
		model: "579",
		engineSize: "12.9 L",
		engineDetails: "PACCAR MX-13, 455 hp, 1,650 lb-ft",
		odometer: 96440,
		status: "in-service",
		notes: "New steers this fall. Drive tires are still original."
	},
	{
		id: "t156",
		number: "156",
		vin: "4V4NC9EH5LN234901",
		plate: "NL-1560",
		spot: "7",
		year: "2020",
		make: "Volvo",
		model: "VNL 760",
		engineSize: "12.8 L",
		engineDetails: "Volvo D13, 425 hp, 1,550 lb-ft",
		odometer: 612004,
		status: "parked",
		notes: "Parked pending resale. Plates stay active through year end."
	},
	{
		id: "t088",
		number: "088",
		vin: "1FUJHHDR2LLKW8831",
		plate: "NL-0884",
		spot: "21",
		year: "2021",
		make: "Freightliner",
		model: "Cascadia",
		engineSize: "15.0 L",
		engineDetails: "Cummins X15, 500 hp, 1,850 lb-ft",
		odometer: 541220,
		status: "in-service",
		notes: "Regional lane. Spec steers are 295/75R22.5."
	},
	{
		id: "t240",
		number: "240",
		vin: "3AKJGLDR5RSUS1104",
		plate: "NL-2409",
		spot: "2",
		year: "2024",
		make: "Kenworth",
		model: "W990",
		engineSize: "14.8 L",
		engineDetails: "Detroit DD15, 505 hp, 1,850 lb-ft",
		odometer: 48910,
		status: "in-service",
		notes: "Lease unit. Spare was mounted this month."
	},
	{
		id: "t119",
		number: "119",
		vin: "1XPBD49X7MD734220",
		plate: "NL-1193",
		spot: "15",
		year: "2019",
		make: "Peterbilt",
		model: "389",
		engineSize: "12.9 L",
		engineDetails: "PACCAR MX-13, 510 hp, 1,850 lb-ft",
		odometer: 704118,
		status: "shop",
		notes: "Oil interval is past. Hold for service before the next load."
	},
	{
		id: "t265",
		number: "265",
		vin: "4V4WC9EH8RN882017",
		plate: "NL-2651",
		spot: "9",
		year: "2023",
		make: "Volvo",
		model: "VNL 860",
		engineSize: "12.8 L",
		engineDetails: "Volvo D13TC turbo compound, 455 hp, 1,850 lb-ft",
		odometer: 221640,
		status: "in-service",
		notes: "Night dispatch. Oil and DEF were on the last shop ticket."
	}
];
var seedTires = [
	{
		id: "tire-214-lf",
		truckId: "t214",
		date: iso(-160),
		position: "LF · steer",
		action: "Mounted",
		brand: "Michelin",
		size: "295/75R22.5",
		tread: "18/32",
		mileage: 398400,
		fee: 612,
		feeKind: "Tire",
		notes: "X Line Energy Z"
	},
	{
		id: "tire-214-labor",
		truckId: "t214",
		date: iso(-160),
		position: "LF · steer",
		action: "Mounted",
		brand: "Michelin",
		size: "295/75R22.5",
		tread: "",
		mileage: 398400,
		fee: 85,
		feeKind: "Labor",
		notes: "Mount and balance"
	},
	{
		id: "tire-214-repair",
		truckId: "t214",
		date: iso(-55),
		position: "RF · steer",
		action: "Repaired",
		brand: "Michelin",
		size: "295/75R22.5",
		tread: "14/32",
		mileage: 408110,
		fee: 68,
		feeKind: "Repair",
		notes: "Nail in the outer rib"
	},
	{
		id: "tire-214-balance",
		truckId: "t214",
		date: iso(-8),
		position: "LF · steer",
		action: "Rotated",
		brand: "",
		size: "",
		tread: "",
		mileage: 412200,
		fee: 40,
		feeKind: "Labor",
		notes: "Balance after a steer shake"
	},
	{
		id: "tire-187-drive",
		truckId: "t187",
		date: iso(-120),
		position: "1LO · drive",
		action: "Replaced",
		brand: "Goodyear",
		size: "295/75R22.5",
		tread: "22/32",
		mileage: 376540,
		fee: 548,
		feeKind: "Tire",
		notes: "Endurance LHS"
	},
	{
		id: "tire-187-disposal",
		truckId: "t187",
		date: iso(-120),
		position: "1LO · drive",
		action: "Disposed",
		brand: "",
		size: "295/75R22.5",
		tread: "4/32",
		mileage: 376540,
		fee: 28,
		feeKind: "Disposal",
		notes: "Casing rejected"
	},
	{
		id: "tire-301-lf",
		truckId: "t301",
		date: iso(-40),
		position: "LF · steer",
		action: "Mounted",
		brand: "Michelin",
		size: "295/75R22.5",
		tread: "18/32",
		mileage: 91220,
		fee: 640,
		feeKind: "Tire",
		notes: ""
	},
	{
		id: "tire-301-rf",
		truckId: "t301",
		date: iso(-40),
		position: "RF · steer",
		action: "Mounted",
		brand: "Michelin",
		size: "295/75R22.5",
		tread: "18/32",
		mileage: 91220,
		fee: 640,
		feeKind: "Tire",
		notes: ""
	},
	{
		id: "tire-301-labor",
		truckId: "t301",
		date: iso(-40),
		position: "LF · steer",
		action: "Mounted",
		brand: "",
		size: "",
		tread: "",
		mileage: 91220,
		fee: 120,
		feeKind: "Labor",
		notes: "Both steers, mount and disposal included in labor only"
	},
	{
		id: "tire-156-retread",
		truckId: "t156",
		date: iso(-150),
		position: "1LO · drive",
		action: "Retreaded",
		brand: "Bandag",
		size: "11R22.5",
		tread: "22/32",
		mileage: 598440,
		fee: 390,
		feeKind: "Retread",
		notes: "Drive recap"
	},
	{
		id: "tire-088-repair",
		truckId: "t088",
		date: iso(-90),
		position: "RF · steer",
		action: "Repaired",
		brand: "Bridgestone",
		size: "295/75R22.5",
		tread: "11/32",
		mileage: 528600,
		fee: 55,
		feeKind: "Repair",
		notes: "Plug, held air"
	},
	{
		id: "tire-088-rotate",
		truckId: "t088",
		date: iso(-12),
		position: "Drive axles",
		action: "Rotated",
		brand: "",
		size: "11R22.5",
		tread: "",
		mileage: 540880,
		fee: 60,
		feeKind: "Labor",
		notes: "Cross rotation on the drives"
	},
	{
		id: "tire-240-spare",
		truckId: "t240",
		date: iso(-16),
		position: "Spare",
		action: "Mounted",
		brand: "Goodyear",
		size: "295/75R22.5",
		tread: "22/32",
		mileage: 47600,
		fee: 480,
		feeKind: "Tire",
		notes: "New spare on the carrier"
	},
	{
		id: "tire-119-set",
		truckId: "t119",
		date: iso(-140),
		position: "Drive axles",
		action: "Replaced",
		brand: "Bandag",
		size: "11R22.5",
		tread: "22/32",
		mileage: 688200,
		fee: 1180,
		feeKind: "Tire",
		notes: "Four drive recaps"
	},
	{
		id: "tire-119-labor",
		truckId: "t119",
		date: iso(-140),
		position: "Drive axles",
		action: "Replaced",
		brand: "",
		size: "",
		tread: "",
		mileage: 688200,
		fee: 210,
		feeKind: "Labor",
		notes: "Pull and mount, both drive axles"
	},
	{
		id: "tire-119-disposal",
		truckId: "t119",
		date: iso(-140),
		position: "Drive axles",
		action: "Disposed",
		brand: "",
		size: "11R22.5",
		tread: "2/32",
		mileage: 688200,
		fee: 80,
		feeKind: "Disposal",
		notes: "Four casings"
	},
	{
		id: "tire-265-rf",
		truckId: "t265",
		date: iso(-60),
		position: "RF · steer",
		action: "Replaced",
		brand: "Continental",
		size: "295/75R22.5",
		tread: "18/32",
		mileage: 214880,
		fee: 625,
		feeKind: "Tire",
		notes: "Irregular wear on the old steer"
	}
];
var seedOils = [
	{
		id: "oil-214",
		truckId: "t214",
		date: iso(-50),
		mileage: 405e3,
		nextDueMileage: 43e4,
		nextDueDate: iso(130),
		oilType: "15W-40 CK-4",
		quantity: "10 gal",
		filter: "Fleetguard LF14000NN",
		fee: 286,
		vendor: "Northline shop",
		notes: "Sample pulled for the lab."
	},
	{
		id: "oil-187",
		truckId: "t187",
		date: iso(-100),
		mileage: 372400,
		nextDueMileage: 389800,
		nextDueDate: iso(70),
		oilType: "10W-30 CK-4",
		quantity: "10 gal",
		filter: "Detroit DD13 kit",
		fee: 310,
		vendor: "Harbor Diesel",
		notes: ""
	},
	{
		id: "oil-187-prev",
		truckId: "t187",
		date: iso(-280),
		mileage: 348100,
		nextDueMileage: 373100,
		nextDueDate: iso(-100),
		oilType: "10W-30 CK-4",
		quantity: "10 gal",
		filter: "Detroit DD13 kit",
		fee: 295,
		vendor: "Harbor Diesel",
		notes: "Previous interval"
	},
	{
		id: "oil-301",
		truckId: "t301",
		date: iso(-140),
		mileage: 78e3,
		nextDueMileage: 97800,
		nextDueDate: iso(16),
		oilType: "10W-30 CK-4",
		quantity: "10 gal",
		filter: "PACCAR MX-13",
		fee: 264,
		vendor: "Northline shop",
		notes: "First shop interval after delivery."
	},
	{
		id: "oil-156",
		truckId: "t156",
		date: iso(-250),
		mileage: 586e3,
		nextDueMileage: 623e3,
		nextDueDate: iso(-70),
		oilType: "15W-40 CK-4",
		quantity: "11 gal",
		filter: "Volvo D13",
		fee: 340,
		vendor: "Yard bay 2",
		notes: "Not serviced again after it was parked."
	},
	{
		id: "oil-088",
		truckId: "t088",
		date: iso(-20),
		mileage: 538900,
		nextDueMileage: 563900,
		nextDueDate: iso(160),
		oilType: "15W-40 CK-4",
		quantity: "10 gal",
		filter: "Fleetguard LF14000NN",
		fee: 298,
		vendor: "Northline shop",
		notes: ""
	},
	{
		id: "oil-088-prev",
		truckId: "t088",
		date: iso(-200),
		mileage: 514e3,
		nextDueMileage: 539e3,
		nextDueDate: iso(-20),
		oilType: "15W-40 CK-4",
		quantity: "10 gal",
		filter: "Fleetguard LF14000NN",
		fee: 280,
		vendor: "Northline shop",
		notes: "Previous interval"
	},
	{
		id: "oil-240",
		truckId: "t240",
		date: iso(-70),
		mileage: 41200,
		nextDueMileage: 66200,
		nextDueDate: iso(110),
		oilType: "5W-30 FA-4",
		quantity: "10 gal",
		filter: "Detroit DD15 kit",
		fee: 255,
		vendor: "Harbor Diesel",
		notes: "Factory spec FA-4. Do not top off with CK-4."
	},
	{
		id: "oil-119",
		truckId: "t119",
		date: iso(-160),
		mileage: 679e3,
		nextDueMileage: 703e3,
		nextDueDate: iso(-18),
		oilType: "15W-40 CK-4",
		quantity: "10 gal",
		filter: "PACCAR MX-13",
		fee: 360,
		vendor: "Roadside — I-80",
		notes: "Interval missed while the truck sat in the shop."
	},
	{
		id: "oil-265",
		truckId: "t265",
		date: iso(-32),
		mileage: 214200,
		nextDueMileage: 239200,
		nextDueDate: iso(148),
		oilType: "10W-30 CK-4",
		quantity: "10 gal",
		filter: "Volvo D13",
		fee: 274,
		vendor: "Northline shop",
		notes: "DEF topped on the same ticket, not in this fee."
	}
];
var TRUCK_STATUSES = [
	"in-service",
	"shop",
	"parked"
];
var STATUS_LABEL = {
	"in-service": "In service",
	shop: "In shop",
	parked: "Parked"
};
var TIRE_POSITIONS = [
	"LF · steer",
	"RF · steer",
	"1LO · drive",
	"1LI · drive",
	"1RO · drive",
	"1RI · drive",
	"2LO · drive",
	"2LI · drive",
	"2RO · drive",
	"2RI · drive",
	"Spare",
	"Drive axles",
	"Other"
];
var TIRE_ACTIONS = [
	"Mounted",
	"Replaced",
	"Rotated",
	"Repaired",
	"Retreaded",
	"Disposed"
];
var FEE_KINDS = [
	"Tire",
	"Labor",
	"Repair",
	"Retread",
	"Disposal",
	"Other"
];
function uid() {
	return crypto.randomUUID();
}
function bump(trucks, truckId, mileage) {
	if (!Number.isFinite(mileage) || mileage <= 0) return trucks;
	return trucks.map((truck) => truck.id === truckId && mileage > truck.odometer ? {
		...truck,
		odometer: mileage
	} : truck);
}
function isRecord(value) {
	return !!value && typeof value === "object";
}
function str(value) {
	return typeof value === "string" ? value : "";
}
function num(value) {
	return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function isStatus(value) {
	return TRUCK_STATUSES.includes(value);
}
function parseBackup(raw) {
	if (!isRecord(raw) || !Array.isArray(raw.trucks) || !Array.isArray(raw.tires) || !Array.isArray(raw.oils)) return null;
	const trucks = [];
	for (const item of raw.trucks) {
		if (!isRecord(item)) return null;
		const status = str(item.status);
		const odometer = num(item.odometer);
		const id = str(item.id);
		if (!id || !isStatus(status) || odometer === null) return null;
		trucks.push({
			id,
			number: str(item.number),
			vin: str(item.vin),
			plate: str(item.plate),
			spot: str(item.spot),
			year: str(item.year),
			make: str(item.make),
			model: str(item.model),
			engineSize: str(item.engineSize),
			engineDetails: str(item.engineDetails),
			odometer,
			status,
			notes: str(item.notes)
		});
	}
	const tires = [];
	for (const item of raw.tires) {
		if (!isRecord(item)) return null;
		const fee = num(item.fee);
		const mileage = num(item.mileage);
		const id = str(item.id);
		const truckId = str(item.truckId);
		if (!id || !truckId || fee === null || mileage === null) return null;
		tires.push({
			id,
			truckId,
			date: str(item.date),
			position: str(item.position),
			action: str(item.action),
			brand: str(item.brand),
			size: str(item.size),
			tread: str(item.tread),
			mileage,
			fee,
			feeKind: str(item.feeKind),
			notes: str(item.notes)
		});
	}
	const oils = [];
	for (const item of raw.oils) {
		if (!isRecord(item)) return null;
		const fee = num(item.fee);
		const mileage = num(item.mileage);
		const nextDueMileage = num(item.nextDueMileage);
		const id = str(item.id);
		const truckId = str(item.truckId);
		if (!id || !truckId || fee === null || mileage === null || nextDueMileage === null) return null;
		oils.push({
			id,
			truckId,
			date: str(item.date),
			mileage,
			nextDueMileage,
			nextDueDate: str(item.nextDueDate),
			oilType: str(item.oilType),
			quantity: str(item.quantity),
			filter: str(item.filter),
			fee,
			vendor: str(item.vendor),
			notes: str(item.notes)
		});
	}
	return {
		trucks,
		tires,
		oils
	};
}
var demo = () => ({
	trucks: seedTrucks,
	tires: seedTires,
	oils: seedOils
});
var useFleet = create()(persist((set) => ({
	...demo(),
	addTruck: (input) => {
		const id = uid();
		set((s) => ({ trucks: [...s.trucks, {
			...input,
			id
		}] }));
		return id;
	},
	updateTruck: (id, patch) => set((s) => ({ trucks: s.trucks.map((truck) => truck.id === id ? {
		...truck,
		...patch
	} : truck) })),
	removeTruck: (id) => set((s) => ({
		trucks: s.trucks.filter((truck) => truck.id !== id),
		tires: s.tires.filter((tire) => tire.truckId !== id),
		oils: s.oils.filter((oil) => oil.truckId !== id)
	})),
	addTire: (input) => {
		const id = uid();
		set((s) => ({
			tires: [{
				...input,
				id
			}, ...s.tires],
			trucks: bump(s.trucks, input.truckId, input.mileage)
		}));
		return id;
	},
	updateTire: (id, patch) => set((s) => {
		const tires = s.tires.map((tire) => tire.id === id ? {
			...tire,
			...patch
		} : tire);
		const next = tires.find((tire) => tire.id === id);
		return {
			tires,
			trucks: next ? bump(s.trucks, next.truckId, next.mileage) : s.trucks
		};
	}),
	removeTire: (id) => set((s) => ({ tires: s.tires.filter((tire) => tire.id !== id) })),
	addOil: (input) => {
		const id = uid();
		set((s) => ({
			oils: [{
				...input,
				id
			}, ...s.oils],
			trucks: bump(s.trucks, input.truckId, input.mileage)
		}));
		return id;
	},
	updateOil: (id, patch) => set((s) => {
		const oils = s.oils.map((oil) => oil.id === id ? {
			...oil,
			...patch
		} : oil);
		const next = oils.find((oil) => oil.id === id);
		return {
			oils,
			trucks: next ? bump(s.trucks, next.truckId, next.mileage) : s.trucks
		};
	}),
	removeOil: (id) => set((s) => ({ oils: s.oils.filter((oil) => oil.id !== id) })),
	importBackup: (data) => set({
		trucks: data.trucks,
		tires: data.tires,
		oils: data.oils
	}),
	resetDemo: () => set(demo())
}), {
	name: "axlehouse-v1",
	skipHydration: true
}));
function FeesView({ query, onOpenTire, onOpenOil, onLogTire, onLogOil }) {
	const trucks = useFleet((s) => s.trucks);
	const tires = useFleet((s) => s.tires);
	const oils = useFleet((s) => s.oils);
	const [kind, setKind] = (0, import_react.useState)("all");
	const [range, setRange] = (0, import_react.useState)("year");
	const year = (/* @__PURE__ */ new Date()).getFullYear();
	const truckMap = new Map(trucks.map((truck) => [truck.id, truck]));
	const visible = [...tires.map((tire) => ({
		id: tire.id,
		date: tire.date,
		truckId: tire.truckId,
		kind: "Tire",
		detail: tireDetail(tire),
		fee: tire.fee,
		source: "tire"
	})), ...oils.map((oil) => ({
		id: oil.id,
		date: oil.date,
		truckId: oil.truckId,
		kind: "Oil",
		detail: oilDetail(oil) || "Oil change",
		fee: oil.fee,
		source: "oil"
	}))].filter((row) => range === "year" ? row.date.startsWith(`${year}-`) : true).filter((row) => kind === "all" ? true : row.source === kind).filter((row) => {
		const truck = truckMap.get(row.truckId);
		return includesQuery([
			truck?.number,
			truck?.plate,
			truck?.vin,
			truck?.spot,
			row.kind,
			row.detail,
			row.date
		].join(" ").toLowerCase(), query);
	}).sort((a, b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id));
	const total = visible.reduce((sum, row) => sum + row.fee, 0);
	const tireTotal = visible.filter((row) => row.source === "tire").reduce((sum, row) => sum + row.fee, 0);
	const oilTotal = visible.filter((row) => row.source === "oil").reduce((sum, row) => sum + row.fee, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl border border-border bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-semibold tracking-tight",
						children: "Ledger"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-mono text-2xl font-medium tabular-nums tracking-tight",
						children: money(total)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: [
							"Tires ",
							money(tireTotal),
							" · Oil ",
							money(oilTotal),
							range === "year" ? ` · ${year}` : " · all dates"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpendChart, { data: monthlySpend(tires, oils) })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
							active: kind === "all",
							onClick: () => setKind("all"),
							children: "All"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
							active: kind === "tire",
							onClick: () => setKind("tire"),
							children: "Tires"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
							active: kind === "oil",
							onClick: () => setKind("oil"),
							children: "Oil"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
							active: range === "year",
							onClick: () => setRange("year"),
							children: year
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
							active: range === "all",
							onClick: () => setRange("all"),
							children: "All time"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: onLogOil,
						children: "Log oil"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: onLogTire,
						children: "Log tire"
					})]
				})]
			}),
			visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-dashed border-border px-4 py-10 text-center text-sm text-muted-foreground",
				children: "No fees in this view."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: visible.map((row) => {
					const truck = truckMap.get(row.truckId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => row.source === "tire" ? onOpenTire(row.id) : onOpenOil(row.id),
						className: "flex w-full items-start justify-between gap-3 rounded-lg border border-border bg-card px-4 py-3 text-left hover:bg-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block font-medium",
									children: [
										truckLabel(truck),
										" · ",
										row.kind
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block truncate text-sm text-muted-foreground",
									children: row.detail
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block font-mono text-xs text-muted-foreground",
									children: shortDate(row.date)
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 font-mono text-sm font-medium tabular-nums",
							children: money(row.fee)
						})]
					}) }, `${row.source}-${row.id}`);
				})
			})
		]
	});
}
function Filter({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: active ? "h-9 rounded-full bg-primary px-3 text-sm font-medium text-primary-foreground" : "h-9 rounded-full border border-border bg-card px-3 text-sm font-medium text-foreground hover:bg-muted",
		children
	});
}
var tones = {
	good: "bg-good/10 text-good",
	warn: "bg-warn/10 text-warn",
	bad: "bg-destructive/10 text-destructive",
	neutral: "bg-muted text-muted-foreground",
	ink: "bg-primary text-primary-foreground"
};
function Badge({ tone = "neutral", children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex h-6 items-center rounded-full px-2 text-xs font-medium", tones[tone], className),
		children
	});
}
var control = "h-11 w-full rounded-md border border-border bg-card px-3 text-sm text-foreground outline-none placeholder:text-muted-foreground/70 focus-visible:border-primary focus-visible:ring-2 focus-visible:ring-primary/20";
function Field({ label, hint, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: cn("flex flex-col gap-1.5", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			children,
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs leading-snug text-muted-foreground",
				children: hint
			}) : null
		]
	});
}
function TextInput({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		autoComplete: "off",
		className: cn(control, className),
		...props
	});
}
function TextArea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn(control, "h-auto min-h-24 py-2.5 leading-normal", className),
		...props
	});
}
function SelectInput({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
			className: cn(control, "appearance-none pr-10", className),
			...props,
			children
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "pointer-events-none absolute top-1/2 right-3 size-4 -translate-y-1/2 text-muted-foreground" })]
	});
}
function Modal({ open, onOpenChange, title, description, children, footer, wide }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-40 bg-foreground/40 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			className: "group pointer-events-none fixed inset-0 z-50 flex items-center justify-center p-4 outline-none",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("pointer-events-auto flex max-h-full w-full flex-col overflow-hidden rounded-xl border border-border bg-card text-foreground shadow-lg", "group-data-[state=open]:animate-in group-data-[state=closed]:animate-out group-data-[state=closed]:fade-out-0 group-data-[state=open]:fade-in-0 group-data-[state=closed]:zoom-out-95 group-data-[state=open]:zoom-in-95", wide ? "max-w-2xl" : "max-w-lg"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3 border-b border-border px-5 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
								className: "text-lg font-semibold tracking-tight",
								children: title
							}), description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
								className: "mt-1 text-sm text-muted-foreground",
								children: description
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
								className: "sr-only",
								children: title
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
							className: "grid size-11 shrink-0 place-items-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground",
							"aria-label": "Close",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "min-h-0 flex-1 overflow-y-auto px-5 py-4",
						children
					}),
					footer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "border-t border-border px-5 py-3",
						children: footer
					}) : null
				]
			})
		})] })
	});
}
function emptyTruck() {
	return {
		number: "",
		vin: "",
		plate: "",
		spot: "",
		year: "",
		make: "",
		model: "",
		engineSize: "",
		engineDetails: "",
		odometer: "",
		status: "in-service",
		notes: ""
	};
}
function emptyTire(truckId = "") {
	const truck = useFleet.getState().trucks.find((item) => item.id === truckId);
	return {
		truckId,
		date: todayISO(),
		position: TIRE_POSITIONS[0],
		action: TIRE_ACTIONS[0],
		brand: "",
		size: "295/75R22.5",
		tread: "",
		mileage: truck ? String(truck.odometer) : "",
		fee: "",
		feeKind: FEE_KINDS[0],
		notes: ""
	};
}
function emptyOil(truckId = "") {
	const truck = useFleet.getState().trucks.find((item) => item.id === truckId);
	const mileage = truck ? truck.odometer : 0;
	return {
		truckId,
		date: todayISO(),
		mileage: truck ? String(truck.odometer) : "",
		nextDueMileage: truck ? String(mileage + 25e3) : "",
		nextDueDate: addDaysISO(180),
		oilType: "15W-40 CK-4",
		quantity: "10 gal",
		filter: "",
		fee: "",
		vendor: "",
		notes: ""
	};
}
function FormError({ message }) {
	if (!message) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		role: "alert",
		className: "text-sm text-destructive",
		children: message
	});
}
function TruckDialog({ open, truckId, onClose, onLogTire, onLogOil }) {
	const trucks = useFleet((s) => s.trucks);
	const tires = useFleet((s) => s.tires);
	const oils = useFleet((s) => s.oils);
	const addTruck = useFleet((s) => s.addTruck);
	const updateTruck = useFleet((s) => s.updateTruck);
	const removeTruck = useFleet((s) => s.removeTruck);
	const [draft, setDraft] = (0, import_react.useState)(emptyTruck);
	const [error, setError] = (0, import_react.useState)("");
	const [confirming, setConfirming] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const current = useFleet.getState().trucks.find((truck) => truck.id === truckId);
		setError("");
		setConfirming(false);
		setCopied(false);
		setDraft(current ? {
			number: current.number,
			vin: current.vin,
			plate: current.plate,
			spot: current.spot,
			year: current.year,
			make: current.make,
			model: current.model,
			engineSize: current.engineSize,
			engineDetails: current.engineDetails,
			odometer: String(current.odometer),
			status: current.status,
			notes: current.notes
		} : emptyTruck());
	}, [open, truckId]);
	const truckTires = tires.filter((tire) => tire.truckId === truckId).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 4);
	const truckOils = oils.filter((oil) => oil.truckId === truckId).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 3);
	const spend = truckId ? spendForTruck(tires, oils, truckId) : null;
	function set(key, value) {
		setDraft((prev) => ({
			...prev,
			[key]: value
		}));
	}
	function save() {
		const number = draft.number.trim();
		const vin = draft.vin.toUpperCase().replace(/\s+/g, "");
		const plate = draft.plate.toUpperCase().trim();
		const spot = draft.spot.trim();
		const engineSize = draft.engineSize.trim();
		const odometer = parseMiles(draft.odometer);
		if (!number || !vin || !plate || !spot || !engineSize) {
			setError("Truck number, VIN, plate, spot, and engine size are required.");
			return;
		}
		if (odometer === null || odometer < 0) {
			setError("Enter the odometer as a number.");
			return;
		}
		if (trucks.some((truck) => truck.id !== truckId && truck.number.trim().toLowerCase() === number.toLowerCase())) {
			setError("That truck number is already in the yard.");
			return;
		}
		if (trucks.some((truck) => truck.id !== truckId && truck.vin.toUpperCase() === vin)) {
			setError("That VIN is already on another truck.");
			return;
		}
		const payload = {
			number,
			vin,
			plate,
			spot,
			year: draft.year.trim(),
			make: draft.make.trim(),
			model: draft.model.trim(),
			engineSize,
			engineDetails: draft.engineDetails.trim(),
			odometer,
			status: draft.status,
			notes: draft.notes.trim()
		};
		if (truckId) updateTruck(truckId, payload);
		else addTruck(payload);
		onClose();
	}
	async function copyVin() {
		if (!draft.vin.trim()) return;
		try {
			await navigator.clipboard.writeText(draft.vin.toUpperCase().replace(/\s+/g, ""));
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1200);
		} catch {
			setCopied(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
		open,
		onOpenChange: (next) => {
			if (!next) onClose();
		},
		wide: true,
		title: truckId ? `Truck ${draft.number || ""}`.trim() : "Add truck",
		description: "Number, VIN, plate, spot, and engine stay with the unit.",
		footer: confirming ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Remove this truck and its tire and oil records?"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: () => setConfirming(false),
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "danger",
					onClick: () => {
						if (truckId) removeTruck(truckId);
						onClose();
					},
					children: "Remove"
				})]
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col-reverse gap-2 sm:flex-row sm:items-center sm:justify-between",
			children: [truckId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				className: "text-destructive hover:bg-destructive/10",
				onClick: () => setConfirming(true),
				children: "Remove truck"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: onClose,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: save,
					children: "Save truck"
				})]
			})]
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Truck number",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: draft.number,
							onChange: (e) => set("number", e.target.value),
							placeholder: "214"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Spot number",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: draft.spot,
							onChange: (e) => set("spot", e.target.value),
							placeholder: "12"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Plate",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: draft.plate,
							onChange: (e) => set("plate", e.target.value),
							placeholder: "NL-2148",
							className: "font-mono uppercase"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Status",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
							value: draft.status,
							onChange: (e) => set("status", e.target.value),
							children: TRUCK_STATUSES.map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: status,
								children: STATUS_LABEL[status]
							}, status))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "VIN",
						hint: "Usually 17 characters. Stored as entered if it is shorter.",
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
								value: draft.vin,
								onChange: (e) => set("vin", e.target.value),
								placeholder: "1FUJGLDR5PLNA4821",
								className: "font-mono uppercase"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								onClick: () => void copyVin(),
								disabled: !draft.vin.trim(),
								children: copied ? "Copied" : "Copy"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Year",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: draft.year,
							onChange: (e) => set("year", e.target.value),
							inputMode: "numeric",
							placeholder: "2023"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Odometer",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: draft.odometer,
							onChange: (e) => set("odometer", e.target.value),
							inputMode: "numeric",
							placeholder: "412880"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Make",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: draft.make,
							onChange: (e) => set("make", e.target.value),
							placeholder: "Freightliner"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Model",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: draft.model,
							onChange: (e) => set("model", e.target.value),
							placeholder: "Cascadia"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Engine size",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: draft.engineSize,
							onChange: (e) => set("engineSize", e.target.value),
							placeholder: "15.0 L"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Engine details",
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: draft.engineDetails,
							onChange: (e) => set("engineDetails", e.target.value),
							placeholder: "Cummins X15, 450 hp, 1,850 lb-ft"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Notes",
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
							value: draft.notes,
							onChange: (e) => set("notes", e.target.value),
							placeholder: "Shop holds, spec tires, lease notes"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormError, { message: error })
			}),
			truckId && spend ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 border-t border-border pt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-medium",
							children: "Service on this truck"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-xs text-muted-foreground tabular-nums",
							children: [
								"Tires ",
								money(spend.tire),
								" · Oil ",
								money(spend.oil)
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							size: "sm",
							onClick: () => onLogTire(truckId),
							children: "Log tire"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							size: "sm",
							onClick: () => onLogOil(truckId),
							children: "Log oil"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3 flex flex-col gap-2",
						children: [
							truckOils.map((oil) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground",
										children: [shortDate(oil.date), " · Oil · "]
									}),
									oilDetail(oil) || "Change",
									" · ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono tabular-nums",
										children: money(oil.fee)
									})
								]
							}, oil.id)),
							truckTires.map((tire) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground",
										children: [shortDate(tire.date), " · Tire · "]
									}),
									tireDetail(tire),
									" · ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono tabular-nums",
										children: money(tire.fee)
									})
								]
							}, tire.id)),
							truckOils.length === 0 && truckTires.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "text-sm text-muted-foreground",
								children: "No tire or oil records yet."
							}) : null
						]
					})
				]
			}) : null
		]
	});
}
function TireDialog({ open, tireId, truckId, onClose }) {
	const trucks = useFleet((s) => s.trucks);
	const addTire = useFleet((s) => s.addTire);
	const updateTire = useFleet((s) => s.updateTire);
	const removeTire = useFleet((s) => s.removeTire);
	const [draft, setDraft] = (0, import_react.useState)(emptyTire());
	const [error, setError] = (0, import_react.useState)("");
	const [confirming, setConfirming] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const current = useFleet.getState().tires.find((tire) => tire.id === tireId);
		setError("");
		setConfirming(false);
		setDraft(current ? {
			truckId: current.truckId,
			date: current.date,
			position: current.position,
			action: current.action,
			brand: current.brand,
			size: current.size,
			tread: current.tread,
			mileage: String(current.mileage),
			fee: String(current.fee),
			feeKind: current.feeKind,
			notes: current.notes
		} : emptyTire(truckId));
	}, [
		open,
		tireId,
		truckId
	]);
	function set(key, value) {
		setDraft((prev) => ({
			...prev,
			[key]: value
		}));
	}
	function save() {
		if (!draft.truckId) {
			setError("Choose a truck first.");
			return;
		}
		if (!draft.date) {
			setError("Enter the date.");
			return;
		}
		const fee = parseMoney(draft.fee);
		const mileage = parseMiles(draft.mileage);
		if (fee === null || fee < 0) {
			setError("Enter the fee. Use 0 if there was no charge.");
			return;
		}
		if (mileage === null || mileage < 0) {
			setError("Enter the mileage.");
			return;
		}
		const payload = {
			truckId: draft.truckId,
			date: draft.date,
			position: draft.position,
			action: draft.action,
			brand: draft.brand.trim(),
			size: draft.size.trim(),
			tread: draft.tread.trim(),
			mileage,
			fee,
			feeKind: draft.feeKind,
			notes: draft.notes.trim()
		};
		if (tireId) updateTire(tireId, payload);
		else addTire(payload);
		onClose();
	}
	const sorted = [...trucks].sort((a, b) => a.number.localeCompare(b.number, void 0, { numeric: true }));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onOpenChange: (next) => {
			if (!next) onClose();
		},
		title: tireId ? "Edit tire record" : "Log tire usage",
		description: "Mounts, repairs, rotations, and the fee for each.",
		footer: confirming ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Remove this tire record?"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: () => setConfirming(false),
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "danger",
					onClick: () => {
						if (tireId) removeTire(tireId);
						onClose();
					},
					children: "Remove"
				})]
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col-reverse gap-2 sm:flex-row sm:items-center sm:justify-between",
			children: [tireId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				className: "text-destructive hover:bg-destructive/10",
				onClick: () => setConfirming(true),
				children: "Remove"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: onClose,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: save,
					disabled: trucks.length === 0,
					children: "Save tire"
				})]
			})]
		}),
		children: trucks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Add a truck before logging tires."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Truck",
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectInput, {
						value: draft.truckId,
						onChange: (e) => {
							const nextId = e.target.value;
							const truck = trucks.find((item) => item.id === nextId);
							setDraft((prev) => ({
								...prev,
								truckId: nextId,
								mileage: !tireId && truck ? String(truck.odometer) : prev.mileage
							}));
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Select a truck"
						}), sorted.map((truck) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: truck.id,
							children: [
								truck.number,
								" · spot ",
								truck.spot,
								" · ",
								truck.plate
							]
						}, truck.id))]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Date",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						type: "date",
						value: draft.date,
						onChange: (e) => set("date", e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Odometer",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: draft.mileage,
						onChange: (e) => set("mileage", e.target.value),
						inputMode: "numeric"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Position",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectInput, {
						value: draft.position,
						onChange: (e) => set("position", e.target.value),
						children: [TIRE_POSITIONS.map((position) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: position }, position)), draft.position && !TIRE_POSITIONS.includes(draft.position) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: draft.position }) : null]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "What happened",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
						value: draft.action,
						onChange: (e) => set("action", e.target.value),
						children: TIRE_ACTIONS.map((action) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: action }, action))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Brand",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: draft.brand,
						onChange: (e) => set("brand", e.target.value),
						placeholder: "Michelin"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Size",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: draft.size,
						onChange: (e) => set("size", e.target.value),
						placeholder: "295/75R22.5"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Tread left",
					hint: "Optional, in 32nds.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: draft.tread,
						onChange: (e) => set("tread", e.target.value),
						placeholder: "14/32"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Fee kind",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
						value: draft.feeKind,
						onChange: (e) => set("feeKind", e.target.value),
						children: FEE_KINDS.map((kind) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: kind }, kind))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Fee",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: draft.fee,
						onChange: (e) => set("fee", e.target.value),
						inputMode: "decimal",
						placeholder: "0.00"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Notes",
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
						value: draft.notes,
						onChange: (e) => set("notes", e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormError, { message: error })
				})
			]
		})
	});
}
function OilDialog({ open, oilId, truckId, onClose }) {
	const trucks = useFleet((s) => s.trucks);
	const addOil = useFleet((s) => s.addOil);
	const updateOil = useFleet((s) => s.updateOil);
	const removeOil = useFleet((s) => s.removeOil);
	const [draft, setDraft] = (0, import_react.useState)(emptyOil());
	const [error, setError] = (0, import_react.useState)("");
	const [confirming, setConfirming] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const current = useFleet.getState().oils.find((oil) => oil.id === oilId);
		setError("");
		setConfirming(false);
		setDraft(current ? {
			truckId: current.truckId,
			date: current.date,
			mileage: String(current.mileage),
			nextDueMileage: String(current.nextDueMileage),
			nextDueDate: current.nextDueDate,
			oilType: current.oilType,
			quantity: current.quantity,
			filter: current.filter,
			fee: String(current.fee),
			vendor: current.vendor,
			notes: current.notes
		} : emptyOil(truckId));
	}, [
		open,
		oilId,
		truckId
	]);
	function set(key, value) {
		setDraft((prev) => ({
			...prev,
			[key]: value
		}));
	}
	function save() {
		if (!draft.truckId) {
			setError("Choose a truck first.");
			return;
		}
		if (!draft.date) {
			setError("Enter the date.");
			return;
		}
		const mileage = parseMiles(draft.mileage);
		const nextDueMileage = parseMiles(draft.nextDueMileage || "0");
		const fee = parseMoney(draft.fee);
		if (mileage === null || mileage < 0) {
			setError("Enter the mileage at the change.");
			return;
		}
		if (nextDueMileage === null || nextDueMileage < 0) {
			setError("Enter the next due mileage, or 0 if you are not tracking it.");
			return;
		}
		if (fee === null || fee < 0) {
			setError("Enter the fee. Use 0 if there was no charge.");
			return;
		}
		const payload = {
			truckId: draft.truckId,
			date: draft.date,
			mileage,
			nextDueMileage,
			nextDueDate: draft.nextDueDate,
			oilType: draft.oilType.trim(),
			quantity: draft.quantity.trim(),
			filter: draft.filter.trim(),
			fee,
			vendor: draft.vendor.trim(),
			notes: draft.notes.trim()
		};
		if (oilId) updateOil(oilId, payload);
		else addOil(payload);
		onClose();
	}
	const sorted = [...trucks].sort((a, b) => a.number.localeCompare(b.number, void 0, { numeric: true }));
	const selected = trucks.find((truck) => truck.id === draft.truckId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
		open,
		onOpenChange: (next) => {
			if (!next) onClose();
		},
		title: oilId ? "Edit oil change" : "Log oil change",
		description: selected ? `${truckLabel(selected)} · ${engineLine(selected)}` : "Interval, oil, and the shop fee.",
		footer: confirming ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Remove this oil change?"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: () => setConfirming(false),
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "danger",
					onClick: () => {
						if (oilId) removeOil(oilId);
						onClose();
					},
					children: "Remove"
				})]
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col-reverse gap-2 sm:flex-row sm:items-center sm:justify-between",
			children: [oilId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				className: "text-destructive hover:bg-destructive/10",
				onClick: () => setConfirming(true),
				children: "Remove"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: onClose,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: save,
					disabled: trucks.length === 0,
					children: "Save oil change"
				})]
			})]
		}),
		children: trucks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Add a truck before logging oil."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Truck",
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectInput, {
						value: draft.truckId,
						onChange: (e) => {
							const nextId = e.target.value;
							const truck = trucks.find((item) => item.id === nextId);
							setDraft((prev) => ({
								...prev,
								truckId: nextId,
								mileage: !oilId && truck ? String(truck.odometer) : prev.mileage,
								nextDueMileage: !oilId && truck ? String(truck.odometer + 25e3) : prev.nextDueMileage
							}));
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Select a truck"
						}), sorted.map((truck) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: truck.id,
							children: [
								truck.number,
								" · spot ",
								truck.spot,
								" · ",
								truck.plate
							]
						}, truck.id))]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Date",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						type: "date",
						value: draft.date,
						onChange: (e) => set("date", e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Mileage",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: draft.mileage,
						onChange: (e) => set("mileage", e.target.value),
						inputMode: "numeric"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Next due mileage",
					hint: "Blank interval uses 25,000 miles on a new record.",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: draft.nextDueMileage,
						onChange: (e) => set("nextDueMileage", e.target.value),
						inputMode: "numeric"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Next due date",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						type: "date",
						value: draft.nextDueDate,
						onChange: (e) => set("nextDueDate", e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Oil",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: draft.oilType,
						onChange: (e) => set("oilType", e.target.value),
						placeholder: "15W-40 CK-4"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Quantity",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: draft.quantity,
						onChange: (e) => set("quantity", e.target.value),
						placeholder: "10 gal"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Filter",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: draft.filter,
						onChange: (e) => set("filter", e.target.value),
						placeholder: "Fleetguard LF14000NN"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Fee",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: draft.fee,
						onChange: (e) => set("fee", e.target.value),
						inputMode: "decimal",
						placeholder: "0.00"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Shop or vendor",
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
						value: draft.vendor,
						onChange: (e) => set("vendor", e.target.value),
						placeholder: "Northline shop"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Notes",
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
						value: draft.notes,
						onChange: (e) => set("notes", e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormError, { message: error })
				})
			]
		})
	});
}
function StatusBadge({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: status === "in-service" ? "good" : status === "shop" ? "warn" : "neutral",
		children: STATUS_LABEL[status]
	});
}
function OilBadge({ tone, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone,
		children: label
	});
}
function OilView({ query, onOpen, onAdd, onOpenTruck }) {
	const trucks = useFleet((s) => s.trucks);
	const oils = useFleet((s) => s.oils);
	const truckMap = new Map(trucks.map((truck) => [truck.id, truck]));
	const schedule = [...trucks].map((truck) => ({
		truck,
		oil: oilStatus(truck, oils)
	})).filter((item) => includesQuery([
		item.truck.number,
		item.truck.plate,
		item.truck.vin,
		item.truck.spot,
		item.oil.label,
		item.oil.detail
	].join(" ").toLowerCase(), query)).sort((a, b) => attentionRank(a.oil.tone) - attentionRank(b.oil.tone) || byNumber(a.truck, b.truck));
	const history = [...oils].filter((oil) => {
		const truck = truckMap.get(oil.truckId);
		return includesQuery([
			truck?.number,
			truck?.plate,
			truck?.vin,
			oil.oilType,
			oil.vendor,
			oil.filter,
			oil.notes,
			oil.quantity
		].join(" ").toLowerCase(), query);
	}).sort((a, b) => b.date.localeCompare(a.date));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "flex flex-col gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold tracking-tight",
					children: "Intervals"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Compared with each truck’s odometer and today’s date."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: onAdd,
					children: "Log oil"
				})]
			}), schedule.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-dashed border-border px-4 py-10 text-center text-sm text-muted-foreground",
				children: "Add a truck to track oil changes."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: schedule.map(({ truck, oil }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onOpenTruck(truck.id),
					className: "flex w-full items-start justify-between gap-3 rounded-lg border border-border bg-card px-4 py-3 text-left hover:bg-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block font-medium",
								children: [
									"Truck ",
									truck.number,
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-normal text-muted-foreground",
										children: [" · spot ", truck.spot]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block truncate text-sm text-muted-foreground",
								children: engineLine(truck)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block text-sm text-muted-foreground",
								children: oil.detail
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OilBadge, {
						tone: oil.tone,
						label: oil.label
					})]
				}) }, truck.id))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "flex flex-col gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-semibold tracking-tight",
				children: "Change history"
			}), history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "No oil changes logged."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: history.map((oil) => {
					const truck = truckMap.get(oil.truckId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onOpen(oil.id),
						className: "flex w-full items-start justify-between gap-3 rounded-lg border border-border bg-card px-4 py-3 text-left hover:bg-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-medium",
									children: truckLabel(truck)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-sm text-muted-foreground",
									children: oilDetail(oil) || "Oil change"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-1 block font-mono text-xs text-muted-foreground tabular-nums",
									children: [
										shortDate(oil.date),
										" · ",
										miles(oil.mileage),
										oil.nextDueMileage ? ` · next ${miles(oil.nextDueMileage)}` : ""
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 font-mono text-sm font-medium tabular-nums",
							children: money(oil.fee)
						})]
					}) }, oil.id);
				})
			})]
		})]
	});
}
function TiresView({ query, onOpen, onAdd }) {
	const trucks = useFleet((s) => s.trucks);
	const tires = useFleet((s) => s.tires);
	const [truckId, setTruckId] = (0, import_react.useState)("all");
	const [kind, setKind] = (0, import_react.useState)("all");
	const truckMap = (0, import_react.useMemo)(() => new Map(trucks.map((truck) => [truck.id, truck])), [trucks]);
	const visible = tires.filter((tire) => truckId === "all" ? true : tire.truckId === truckId).filter((tire) => kind === "all" ? true : tire.feeKind === kind).filter((tire) => {
		const truck = truckMap.get(tire.truckId);
		return includesQuery([
			truck?.number,
			truck?.plate,
			truck?.vin,
			truck?.spot,
			tire.brand,
			tire.size,
			tire.position,
			tire.action,
			tire.feeKind,
			tire.notes
		].join(" ").toLowerCase(), query);
	}).sort((a, b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id));
	const total = visible.reduce((sum, tire) => sum + tire.fee, 0);
	const sortedTrucks = [...trucks].sort(byNumber);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold tracking-tight",
					children: "Tire usage and fees"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						visible.length,
						" ",
						visible.length === 1 ? "record" : "records",
						" · ",
						money(total)
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: onAdd,
					children: "Log tire"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectInput, {
					value: truckId,
					onChange: (e) => setTruckId(e.target.value),
					"aria-label": "Filter by truck",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "all",
						children: "All trucks"
					}), sortedTrucks.map((truck) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
						value: truck.id,
						children: ["Truck ", truck.number]
					}, truck.id))]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectInput, {
					value: kind,
					onChange: (e) => setKind(e.target.value),
					"aria-label": "Filter by fee kind",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "all",
						children: "All fee kinds"
					}), FEE_KINDS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))]
				})]
			}),
			visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-dashed border-border px-4 py-10 text-center text-sm text-muted-foreground",
				children: tires.length === 0 ? "No tire fees yet. Log a mount, repair, or disposal." : "Nothing matches those filters."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: visible.map((tire) => {
					const truck = truckMap.get(tire.truckId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onOpen(tire.id),
						className: "flex w-full items-start justify-between gap-3 rounded-lg border border-border bg-card px-4 py-3 text-left hover:bg-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block font-medium",
									children: [
										truckLabel(truck),
										" · ",
										tire.feeKind
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-sm text-muted-foreground",
									children: tireDetail(tire)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-1 block font-mono text-xs text-muted-foreground tabular-nums",
									children: [
										shortDate(tire.date),
										" · ",
										miles(tire.mileage),
										tire.tread ? ` · ${tire.tread}` : ""
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 font-mono text-sm font-medium tabular-nums",
							children: money(tire.fee)
						})]
					}) }, tire.id);
				})
			})
		]
	});
}
function TrucksView({ query, onOpenTruck, onAdd }) {
	const trucks = useFleet((s) => s.trucks);
	const oils = useFleet((s) => s.oils);
	const visible = trucks.filter((truck) => includesQuery(truckHay(truck), query)).sort(byNumber);
	if (trucks.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
		title: "No trucks yet",
		body: "Add a unit to keep its number, VIN, plate, spot, and engine in one place.",
		action: "Add truck",
		onAction: onAdd
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm text-muted-foreground",
			children: [
				visible.length,
				" of ",
				trucks.length,
				" ",
				trucks.length === 1 ? "truck" : "trucks"
			]
		}), visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-xl border border-dashed border-border px-4 py-10 text-center text-sm text-muted-foreground",
			children: "No trucks match that search."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-2",
			children: visible.map((truck) => {
				const oil = oilStatus(truck, oils);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onOpenTruck(truck.id),
					className: "flex w-full flex-col gap-3 rounded-lg border border-border bg-card px-4 py-3 text-left hover:bg-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30 sm:flex-row sm:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-base font-semibold tracking-tight",
										children: ["Truck ", truck.number]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: truck.status }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OilBadge, {
										tone: oil.tone,
										label: oil.label
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: unitLine(truck) || "Unit not set"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 truncate text-sm text-muted-foreground",
								children: engineLine(truck)
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "grid grid-cols-2 gap-x-6 gap-y-1 text-sm sm:grid-cols-1 sm:text-right",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs text-muted-foreground",
								children: "Spot"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-mono tabular-nums",
								children: truck.spot
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs text-muted-foreground",
								children: "Plate"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-mono",
								children: truck.plate
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "col-span-2 sm:col-span-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-xs text-muted-foreground",
									children: "VIN"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "truncate font-mono text-xs sm:text-sm",
									children: truck.vin
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-xs text-muted-foreground",
								children: "Odometer"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-mono text-xs tabular-nums sm:text-sm",
								children: miles(truck.odometer)
							})] })
						]
					})]
				}) }, truck.id);
			})
		})]
	});
}
function Empty({ title, body, action, onAction }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-3 rounded-xl border border-dashed border-border px-6 py-14 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-semibold tracking-tight",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-sm text-sm text-muted-foreground",
				children: body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: onAction,
				children: action
			})
		]
	});
}
function YardView({ query, onOpenTruck }) {
	const trucks = useFleet((s) => s.trucks);
	const tires = useFleet((s) => s.tires);
	const oils = useFleet((s) => s.oils);
	const year = (/* @__PURE__ */ new Date()).getFullYear();
	const totals = sumInYear(tires, oils, year);
	const shared = sharedSpotIds(trucks);
	const visible = trucks.filter((truck) => includesQuery(truckHay(truck), query)).sort(bySpot);
	const attention = trucks.map((truck) => ({
		truck,
		oil: oilStatus(truck, oils)
	})).filter((item) => item.oil.tone !== "good").filter((item) => includesQuery(truckHay(item.truck), query)).sort((a, b) => attentionRank(a.oil.tone) - attentionRank(b.oil.tone) || bySpot(a.truck, b.truck));
	const chart = monthlySpend(tires, oils);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Trucks",
						value: String(trucks.length),
						hint: query ? `${visible.length} match the search` : "On the yard"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: `Tire fees ${year}`,
						value: money(totals.tire),
						hint: "Mounts, repairs, disposal"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: `Oil fees ${year}`,
						value: money(totals.oil),
						hint: "Changes logged this year"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Oil attention",
						value: String(trucks.filter((truck) => oilStatus(truck, oils).tone !== "good").length),
						hint: "Overdue, due soon, or missing"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-xl border border-border bg-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-base font-semibold tracking-tight",
							children: "Fees, last 6 months"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "Tire charges against oil changes."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpendChart, { data: chart })
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-xl border border-border bg-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-base font-semibold tracking-tight",
							children: "Oil attention"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "Due inside 2,000 miles or 21 days, or already past."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 flex flex-col gap-2",
							children: attention.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "text-sm text-muted-foreground",
								children: "Nothing is due. Every logged truck is inside its interval."
							}) : attention.map(({ truck, oil }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onOpenTruck(truck.id),
								className: "flex w-full items-start justify-between gap-3 rounded-md px-2 py-2 text-left hover:bg-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block font-medium",
									children: ["Truck ", truck.number]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm text-muted-foreground",
									children: oil.detail
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OilBadge, {
									tone: oil.tone,
									label: oil.label
								})]
							}) }, truck.id))
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-3 flex items-end justify-between gap-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold tracking-tight",
					children: "Spots"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						visible.length,
						" ",
						visible.length === 1 ? "truck" : "trucks",
						shared.size ? ` · ${shared.size} sharing a spot` : ""
					]
				})] })
			}), visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-dashed border-border px-4 py-10 text-center text-sm text-muted-foreground",
				children: trucks.length === 0 ? "No trucks on the yard yet." : "No trucks match that search."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-3",
				children: visible.map((truck) => {
					const oil = oilStatus(truck, oils);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onOpenTruck(truck.id),
						className: "flex flex-col rounded-xl border border-border bg-card p-4 text-left hover:bg-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-xs tracking-wide text-muted-foreground",
									children: "Spot"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-2xl font-medium tabular-nums tracking-tight",
									children: truck.spot
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: truck.status })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4 text-lg font-semibold tracking-tight",
								children: ["Truck ", truck.number]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: unitLine(truck) || "Unit not set"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 font-mono text-sm tabular-nums",
								children: truck.plate
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 line-clamp-2 text-sm text-muted-foreground",
								children: engineLine(truck)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs text-muted-foreground tabular-nums",
									children: miles(truck.odometer)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OilBadge, {
									tone: oil.tone,
									label: oil.label
								})]
							}),
							shared.has(truck.id) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-warn",
								children: "Another truck is on this spot."
							}) : null
						]
					}, truck.id);
				})
			})] })
		]
	});
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-mono text-2xl font-medium tabular-nums tracking-tight",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: hint
			})
		]
	});
}
var NAV = [
	{
		id: "yard",
		label: "Yard",
		icon: LayoutGrid,
		blurb: "Spots, spend, and what is due"
	},
	{
		id: "trucks",
		label: "Trucks",
		icon: Truck,
		blurb: "Numbers, VINs, plates, and engines"
	},
	{
		id: "tires",
		label: "Tires",
		icon: CircleDot,
		blurb: "Usage and tire fees"
	},
	{
		id: "oil",
		label: "Oil",
		icon: Droplet,
		blurb: "Changes and intervals"
	},
	{
		id: "fees",
		label: "Fees",
		icon: Receipt,
		blurb: "Every charge in one ledger"
	}
];
function FleetApp() {
	const [view, setView] = (0, import_react.useState)("yard");
	const [query, setQuery] = (0, import_react.useState)("");
	const [dialog, setDialog] = (0, import_react.useState)(null);
	const [notice, setNotice] = (0, import_react.useState)("");
	const [pendingImport, setPendingImport] = (0, import_react.useState)(null);
	const [confirmSample, setConfirmSample] = (0, import_react.useState)(false);
	const fileRef = (0, import_react.useRef)(null);
	const current = NAV.find((item) => item.id === view) ?? NAV[0];
	(0, import_react.useEffect)(() => {
		useFleet.persist.rehydrate();
	}, []);
	function exportBackup() {
		const { trucks, tires, oils } = useFleet.getState();
		const blob = new Blob([JSON.stringify({
			trucks,
			tires,
			oils
		}, null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = `axlehouse-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
		link.click();
		URL.revokeObjectURL(url);
		setNotice("Backup downloaded.");
	}
	function onFile(file) {
		const reader = new FileReader();
		reader.onload = () => {
			try {
				const parsed = parseBackup(JSON.parse(String(reader.result)));
				if (!parsed) {
					setNotice("That file is not an Axlehouse backup.");
					return;
				}
				setPendingImport(parsed);
			} catch {
				setNotice("Could not read that file.");
			}
		};
		reader.readAsText(file);
	}
	const primary = view === "tires" || view === "fees" ? {
		label: "Log tire",
		run: () => setDialog({ type: "tire" })
	} : view === "oil" ? {
		label: "Log oil",
		run: () => setDialog({ type: "oil" })
	} : {
		label: "Add truck",
		run: () => setDialog({ type: "truck" })
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground lg:grid lg:grid-cols-[220px_minmax(0,1fr)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "border-b border-border bg-card lg:sticky lg:top-0 lg:flex lg:h-dvh lg:flex-col lg:border-r lg:border-b-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-4 py-4 lg:px-5 lg:pt-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs tracking-widest text-muted-foreground",
							children: "FLEET YARD"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-xl font-semibold tracking-tight",
							children: "Axlehouse"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex gap-1 overflow-x-auto px-3 pb-3 lg:flex-col lg:overflow-visible lg:px-3",
						"aria-label": "Sections",
						children: NAV.map((item) => {
							const Icon = item.icon;
							const active = view === item.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setView(item.id),
								className: cn("flex h-11 shrink-0 items-center gap-2 rounded-md px-3 text-sm font-medium", active ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted hover:text-foreground"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-4",
									"aria-hidden": true
								}), item.label]
							}, item.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-auto hidden px-5 py-5 text-xs leading-relaxed text-muted-foreground lg:block",
						children: "Records stay in this browser. Export a backup before you clear site data."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
					className: "border-b border-border bg-background/90 px-4 py-4 sm:px-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto flex max-w-5xl flex-col gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-2xl font-semibold tracking-tight",
									children: current.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground",
									children: current.blurb
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex shrink-0 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "secondary",
											size: "icon",
											"aria-label": "Export backup",
											onClick: exportBackup,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "secondary",
											size: "icon",
											"aria-label": "Import backup",
											onClick: () => fileRef.current?.click(),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											className: "hidden sm:inline-flex",
											onClick: primary.run,
											children: primary.label
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-2 sm:flex-row sm:items-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "relative block min-w-0 flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "sr-only",
											children: "Search trucks, VINs, plates, and spots"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: query,
											onChange: (event) => setQuery(event.target.value),
											placeholder: "Search truck, VIN, plate, spot",
											className: "h-11 w-full rounded-md border border-border bg-card pr-3 pl-10 text-sm outline-none placeholder:text-muted-foreground/70 focus-visible:border-primary focus-visible:ring-2 focus-visible:ring-primary/20"
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									className: "sm:hidden",
									onClick: primary.run,
									children: primary.label
								})]
							}),
							notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted-foreground",
								children: [
									notice,
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "font-medium text-foreground underline",
										onClick: () => setNotice(""),
										children: "Dismiss"
									})
								]
							}) : null
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "mx-auto max-w-5xl px-4 py-6 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rise",
						children: [
							view === "yard" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(YardView, {
								query,
								onOpenTruck: (id) => setDialog({
									type: "truck",
									id
								})
							}) : null,
							view === "trucks" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrucksView, {
								query,
								onOpenTruck: (id) => setDialog({
									type: "truck",
									id
								}),
								onAdd: () => setDialog({ type: "truck" })
							}) : null,
							view === "tires" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TiresView, {
								query,
								onOpen: (id) => setDialog({
									type: "tire",
									id
								}),
								onAdd: () => setDialog({ type: "tire" })
							}) : null,
							view === "oil" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OilView, {
								query,
								onOpen: (id) => setDialog({
									type: "oil",
									id
								}),
								onAdd: () => setDialog({ type: "oil" }),
								onOpenTruck: (id) => setDialog({
									type: "truck",
									id
								})
							}) : null,
							view === "fees" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeesView, {
								query,
								onOpenTire: (id) => setDialog({
									type: "tire",
									id
								}),
								onOpenOil: (id) => setDialog({
									type: "oil",
									id
								}),
								onLogTire: () => setDialog({ type: "tire" }),
								onLogOil: () => setDialog({ type: "oil" })
							}) : null
						]
					}, view), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
						className: "mt-10 flex flex-col gap-3 border-t border-border pt-4 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Saved on this device." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "sm",
								onClick: exportBackup,
								children: "Export backup"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "sm",
								onClick: () => setConfirmSample(true),
								children: "Load sample yard"
							})]
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: fileRef,
				type: "file",
				accept: "application/json,.json",
				className: "sr-only",
				onChange: (event) => {
					const file = event.target.files?.[0];
					event.target.value = "";
					if (file) onFile(file);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TruckDialog, {
				open: dialog?.type === "truck",
				truckId: dialog?.type === "truck" ? dialog.id : void 0,
				onClose: () => setDialog(null),
				onLogTire: (id) => setDialog({
					type: "tire",
					truckId: id
				}),
				onLogOil: (id) => setDialog({
					type: "oil",
					truckId: id
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TireDialog, {
				open: dialog?.type === "tire",
				tireId: dialog?.type === "tire" ? dialog.id : void 0,
				truckId: dialog?.type === "tire" ? dialog.truckId : void 0,
				onClose: () => setDialog(null)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OilDialog, {
				open: dialog?.type === "oil",
				oilId: dialog?.type === "oil" ? dialog.id : void 0,
				truckId: dialog?.type === "oil" ? dialog.truckId : void 0,
				onClose: () => setDialog(null)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				open: pendingImport !== null,
				onOpenChange: (open) => {
					if (!open) setPendingImport(null);
				},
				title: "Replace the yard?",
				description: pendingImport ? `This backup has ${pendingImport.trucks.length} trucks, ${pendingImport.tires.length} tire records, and ${pendingImport.oils.length} oil changes. Current records on this device will be overwritten.` : "",
				footer: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: () => setPendingImport(null),
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => {
							if (pendingImport) {
								useFleet.getState().importBackup(pendingImport);
								setNotice(`Imported ${pendingImport.trucks.length} trucks.`);
							}
							setPendingImport(null);
						},
						children: "Replace records"
					})]
				}),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Export a backup first if you still need what is here now."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				open: confirmSample,
				onOpenChange: setConfirmSample,
				title: "Load the sample yard?",
				description: "Replaces everything on this device with the Northline sample: eight trucks, tire fees, and oil changes.",
				footer: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: () => setConfirmSample(false),
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "danger",
						onClick: () => {
							useFleet.getState().resetDemo();
							setConfirmSample(false);
							setNotice("Sample yard loaded.");
						},
						children: "Load sample"
					})]
				}),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Your current trucks, tires, and oil records will be removed from this browser."
				})
			})
		]
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => SplitComponent });
var SplitComponent = FleetApp;
//#endregion
export { money as n, routes_exports as t };
