import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as money } from "./routes-DTPcf6HY.mjs";
import { a as Bar, i as CartesianGrid, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/spend-chart-inner-D3mbx6yT.js
var import_jsx_runtime = require_jsx_runtime();
function axisMoney(value) {
	if (Math.abs(value) >= 1e3) {
		const compact = value / 1e3;
		const digits = Math.abs(compact) >= 10 ? 0 : 1;
		return `$${compact.toFixed(digits)}k`;
	}
	return `$${Math.round(value)}`;
}
function SpendChartInner({ data }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-52 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
				data,
				margin: {
					top: 8,
					right: 0,
					left: 0,
					bottom: 0
				},
				barGap: 2,
				barCategoryGap: "28%",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
						vertical: false,
						stroke: "var(--color-border)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "label",
						axisLine: false,
						tickLine: false,
						tick: {
							fill: "var(--color-muted-foreground)",
							fontSize: 12
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						axisLine: false,
						tickLine: false,
						width: 48,
						tick: {
							fill: "var(--color-muted-foreground)",
							fontSize: 12
						},
						tickFormatter: axisMoney
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
						cursor: { fill: "var(--color-muted)" },
						content: ({ active, payload, label }) => {
							if (!active || !payload?.length) return null;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md border border-border bg-card px-3 py-2 text-xs shadow-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mb-1 font-medium text-foreground",
									children: label
								}), payload.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between gap-4 text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-foreground tabular-nums",
										children: money(Number(item.value ?? 0))
									})]
								}, String(item.name)))]
							});
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
						dataKey: "tires",
						name: "Tires",
						fill: "var(--color-primary)",
						radius: [
							4,
							4,
							0,
							0
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
						dataKey: "oil",
						name: "Oil",
						fill: "var(--color-muted-foreground)",
						radius: [
							4,
							4,
							0,
							0
						]
					})
				]
			})
		})
	});
}
//#endregion
export { SpendChartInner };
