import { type ReactNode } from "react";
import { cn } from "@/lib/utils";

const tones = {
  good: "bg-good/10 text-good",
  warn: "bg-warn/10 text-warn",
  bad: "bg-destructive/10 text-destructive",
  neutral: "bg-muted text-muted-foreground",
  ink: "bg-primary text-primary-foreground",
};

export function Badge({
  tone = "neutral",
  children,
  className,
}: {
  tone?: keyof typeof tones;
  children: ReactNode;
  className?: string;
}) {
  return (
    <span className={cn("inline-flex h-6 items-center rounded-full px-2 text-xs font-medium", tones[tone], className)}>
      {children}
    </span>
  );
}
