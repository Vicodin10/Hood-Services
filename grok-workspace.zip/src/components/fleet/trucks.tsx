import { OilBadge, StatusBadge } from "@/components/fleet/forms";
import { Button } from "@/components/ui/button";
import { byNumber, engineLine, includesQuery, oilStatus, truckHay, unitLine } from "@/lib/fleet/domain";
import { miles } from "@/lib/fleet/format";
import { useFleet } from "@/lib/fleet/store";

export function TrucksView({
  query,
  onOpenTruck,
  onAdd,
}: {
  query: string;
  onOpenTruck: (id: string) => void;
  onAdd: () => void;
}) {
  const trucks = useFleet((s) => s.trucks);
  const oils = useFleet((s) => s.oils);
  const visible = trucks.filter((truck) => includesQuery(truckHay(truck), query)).sort(byNumber);

  if (trucks.length === 0) {
    return (
      <Empty
        title="No trucks yet"
        body="Add a unit to keep its number, VIN, plate, spot, and engine in one place."
        action="Add truck"
        onAction={onAdd}
      />
    );
  }

  return (
    <div className="flex flex-col gap-2">
      <p className="text-sm text-muted-foreground">
        {visible.length} of {trucks.length} {trucks.length === 1 ? "truck" : "trucks"}
      </p>
      {visible.length === 0 ? (
        <p className="rounded-xl border border-dashed border-border px-4 py-10 text-center text-sm text-muted-foreground">
          No trucks match that search.
        </p>
      ) : (
        <ul className="flex flex-col gap-2">
          {visible.map((truck) => {
            const oil = oilStatus(truck, oils);
            return (
              <li key={truck.id}>
                <button
                  type="button"
                  onClick={() => onOpenTruck(truck.id)}
                  className="flex w-full flex-col gap-3 rounded-lg border border-border bg-card px-4 py-3 text-left hover:bg-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30 sm:flex-row sm:items-center"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-base font-semibold tracking-tight">Truck {truck.number}</span>
                      <StatusBadge status={truck.status} />
                      <OilBadge tone={oil.tone} label={oil.label} />
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">{unitLine(truck) || "Unit not set"}</p>
                    <p className="mt-1 truncate text-sm text-muted-foreground">{engineLine(truck)}</p>
                  </div>
                  <dl className="grid grid-cols-2 gap-x-6 gap-y-1 text-sm sm:grid-cols-1 sm:text-right">
                    <div>
                      <dt className="text-xs text-muted-foreground">Spot</dt>
                      <dd className="font-mono tabular-nums">{truck.spot}</dd>
                    </div>
                    <div>
                      <dt className="text-xs text-muted-foreground">Plate</dt>
                      <dd className="font-mono">{truck.plate}</dd>
                    </div>
                    <div className="col-span-2 sm:col-span-1">
                      <dt className="text-xs text-muted-foreground">VIN</dt>
                      <dd className="truncate font-mono text-xs sm:text-sm">{truck.vin}</dd>
                    </div>
                    <div>
                      <dt className="text-xs text-muted-foreground">Odometer</dt>
                      <dd className="font-mono text-xs tabular-nums sm:text-sm">{miles(truck.odometer)}</dd>
                    </div>
                  </dl>
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function Empty({
  title,
  body,
  action,
  onAction,
}: {
  title: string;
  body: string;
  action: string;
  onAction: () => void;
}) {
  return (
    <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed border-border px-6 py-14 text-center">
      <h2 className="text-lg font-semibold tracking-tight">{title}</h2>
      <p className="max-w-sm text-sm text-muted-foreground">{body}</p>
      <Button onClick={onAction}>{action}</Button>
    </div>
  );
}
