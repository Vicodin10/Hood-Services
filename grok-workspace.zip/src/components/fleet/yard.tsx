import { SpendChart } from "@/components/fleet/chart";
import { OilBadge, StatusBadge } from "@/components/fleet/forms";
import {
  attentionRank,
  bySpot,
  engineLine,
  includesQuery,
  monthlySpend,
  oilStatus,
  sharedSpotIds,
  sumInYear,
  truckHay,
  unitLine,
} from "@/lib/fleet/domain";
import { miles, money } from "@/lib/fleet/format";
import { useFleet } from "@/lib/fleet/store";

export function YardView({ query, onOpenTruck }: { query: string; onOpenTruck: (id: string) => void }) {
  const trucks = useFleet((s) => s.trucks);
  const tires = useFleet((s) => s.tires);
  const oils = useFleet((s) => s.oils);
  const year = new Date().getFullYear();
  const totals = sumInYear(tires, oils, year);
  const shared = sharedSpotIds(trucks);
  const visible = trucks.filter((truck) => includesQuery(truckHay(truck), query)).sort(bySpot);
  const attention = trucks
    .map((truck) => ({ truck, oil: oilStatus(truck, oils) }))
    .filter((item) => item.oil.tone !== "good")
    .filter((item) => includesQuery(truckHay(item.truck), query))
    .sort((a, b) => attentionRank(a.oil.tone) - attentionRank(b.oil.tone) || bySpot(a.truck, b.truck));
  const chart = monthlySpend(tires, oils);

  return (
    <div className="flex flex-col gap-6">
      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Trucks" value={String(trucks.length)} hint={query ? `${visible.length} match the search` : "On the yard"} />
        <Stat label={`Tire fees ${year}`} value={money(totals.tire)} hint="Mounts, repairs, disposal" />
        <Stat label={`Oil fees ${year}`} value={money(totals.oil)} hint="Changes logged this year" />
        <Stat
          label="Oil attention"
          value={String(trucks.filter((truck) => oilStatus(truck, oils).tone !== "good").length)}
          hint="Overdue, due soon, or missing"
        />
      </section>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
        <section className="rounded-xl border border-border bg-card p-4">
          <h2 className="text-base font-semibold tracking-tight">Fees, last 6 months</h2>
          <p className="mt-1 text-sm text-muted-foreground">Tire charges against oil changes.</p>
          <div className="mt-4">
            <SpendChart data={chart} />
          </div>
        </section>
        <section className="rounded-xl border border-border bg-card p-4">
          <h2 className="text-base font-semibold tracking-tight">Oil attention</h2>
          <p className="mt-1 text-sm text-muted-foreground">Due inside 2,000 miles or 21 days, or already past.</p>
          <ul className="mt-4 flex flex-col gap-2">
            {attention.length === 0 ? (
              <li className="text-sm text-muted-foreground">Nothing is due. Every logged truck is inside its interval.</li>
            ) : (
              attention.map(({ truck, oil }) => (
                <li key={truck.id}>
                  <button
                    type="button"
                    onClick={() => onOpenTruck(truck.id)}
                    className="flex w-full items-start justify-between gap-3 rounded-md px-2 py-2 text-left hover:bg-muted"
                  >
                    <span>
                      <span className="block font-medium">Truck {truck.number}</span>
                      <span className="block text-sm text-muted-foreground">{oil.detail}</span>
                    </span>
                    <OilBadge tone={oil.tone} label={oil.label} />
                  </button>
                </li>
              ))
            )}
          </ul>
        </section>
      </div>

      <section>
        <div className="mb-3 flex items-end justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold tracking-tight">Spots</h2>
            <p className="text-sm text-muted-foreground">
              {visible.length} {visible.length === 1 ? "truck" : "trucks"}
              {shared.size ? ` · ${shared.size} sharing a spot` : ""}
            </p>
          </div>
        </div>
        {visible.length === 0 ? (
          <p className="rounded-xl border border-dashed border-border px-4 py-10 text-center text-sm text-muted-foreground">
            {trucks.length === 0 ? "No trucks on the yard yet." : "No trucks match that search."}
          </p>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            {visible.map((truck) => {
              const oil = oilStatus(truck, oils);
              return (
                <button
                  key={truck.id}
                  type="button"
                  onClick={() => onOpenTruck(truck.id)}
                  className="flex flex-col rounded-xl border border-border bg-card p-4 text-left hover:bg-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-mono text-xs tracking-wide text-muted-foreground">Spot</p>
                      <p className="font-mono text-2xl font-medium tabular-nums tracking-tight">{truck.spot}</p>
                    </div>
                    <StatusBadge status={truck.status} />
                  </div>
                  <p className="mt-4 text-lg font-semibold tracking-tight">Truck {truck.number}</p>
                  <p className="text-sm text-muted-foreground">{unitLine(truck) || "Unit not set"}</p>
                  <p className="mt-3 font-mono text-sm tabular-nums">{truck.plate}</p>
                  <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{engineLine(truck)}</p>
                  <div className="mt-4 flex items-center justify-between gap-2">
                    <span className="font-mono text-xs text-muted-foreground tabular-nums">{miles(truck.odometer)}</span>
                    <OilBadge tone={oil.tone} label={oil.label} />
                  </div>
                  {shared.has(truck.id) ? (
                    <p className="mt-2 text-xs text-warn">Another truck is on this spot.</p>
                  ) : null}
                </button>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}

function Stat({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">{label}</p>
      <p className="mt-2 font-mono text-2xl font-medium tabular-nums tracking-tight">{value}</p>
      <p className="mt-1 text-sm text-muted-foreground">{hint}</p>
    </div>
  );
}
