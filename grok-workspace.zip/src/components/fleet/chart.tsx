import { useEffect, useState, type ComponentType } from "react";
import type { MonthPoint } from "@/lib/fleet/domain";

export function SpendChart({ data }: { data: MonthPoint[] }) {
  const [Inner, setInner] = useState<ComponentType<{ data: MonthPoint[] }> | null>(null);

  useEffect(() => {
    let live = true;
    void import("./spend-chart-inner").then((mod) => {
      if (live) setInner(() => mod.SpendChartInner);
    });
    return () => {
      live = false;
    };
  }, []);

  return (
    <div>
      {Inner ? <Inner data={data} /> : <div className="h-52 rounded-md bg-muted" />}
      <div className="mt-3 flex gap-4 text-xs text-muted-foreground">
        <span className="inline-flex items-center gap-2">
          <span className="size-2.5 rounded-sm bg-primary" />
          Tires
        </span>
        <span className="inline-flex items-center gap-2">
          <span className="size-2.5 rounded-sm bg-muted-foreground" />
          Oil
        </span>
      </div>
    </div>
  );
}
