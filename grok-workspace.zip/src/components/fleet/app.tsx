import { useEffect, useRef, useState } from "react";
import { CircleDot, Download, Droplet, LayoutGrid, Receipt, Search, Truck, Upload } from "lucide-react";
import { FeesView } from "@/components/fleet/fees";
import { OilDialog, TireDialog, TruckDialog } from "@/components/fleet/forms";
import { OilView } from "@/components/fleet/oil";
import { TiresView } from "@/components/fleet/tires";
import { TrucksView } from "@/components/fleet/trucks";
import { YardView } from "@/components/fleet/yard";
import { Button } from "@/components/ui/button";
import { Modal } from "@/components/ui/modal";
import { parseBackup, useFleet } from "@/lib/fleet/store";
import type { FleetBackup } from "@/lib/fleet/types";
import { cn } from "@/lib/utils";

type ViewId = "yard" | "trucks" | "tires" | "oil" | "fees";

const NAV: { id: ViewId; label: string; icon: typeof Truck; blurb: string }[] = [
  { id: "yard", label: "Yard", icon: LayoutGrid, blurb: "Spots, spend, and what is due" },
  { id: "trucks", label: "Trucks", icon: Truck, blurb: "Numbers, VINs, plates, and engines" },
  { id: "tires", label: "Tires", icon: CircleDot, blurb: "Usage and tire fees" },
  { id: "oil", label: "Oil", icon: Droplet, blurb: "Changes and intervals" },
  { id: "fees", label: "Fees", icon: Receipt, blurb: "Every charge in one ledger" },
];

type DialogState =
  | { type: "truck"; id?: string }
  | { type: "tire"; id?: string; truckId?: string }
  | { type: "oil"; id?: string; truckId?: string }
  | null;

export function FleetApp() {
  const [view, setView] = useState<ViewId>("yard");
  const [query, setQuery] = useState("");
  const [dialog, setDialog] = useState<DialogState>(null);
  const [notice, setNotice] = useState("");
  const [pendingImport, setPendingImport] = useState<FleetBackup | null>(null);
  const [confirmSample, setConfirmSample] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const current = NAV.find((item) => item.id === view) ?? NAV[0];

  useEffect(() => {
    void useFleet.persist.rehydrate();
  }, []);

  function exportBackup() {
    const { trucks, tires, oils } = useFleet.getState();
    const blob = new Blob([JSON.stringify({ trucks, tires, oils }, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `axlehouse-${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
    setNotice("Backup downloaded.");
  }

  function onFile(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = parseBackup(JSON.parse(String(reader.result)));
        if (!parsed) {
          setNotice("That file is not an Axlehouse backup.");
          return;
        }
        setPendingImport(parsed);
      } catch {
        setNotice("Could not read that file.");
      }
    };
    reader.readAsText(file);
  }

  const primary =
    view === "tires" || view === "fees"
      ? { label: "Log tire", run: () => setDialog({ type: "tire" }) }
      : view === "oil"
        ? { label: "Log oil", run: () => setDialog({ type: "oil" }) }
        : { label: "Add truck", run: () => setDialog({ type: "truck" }) };

  return (
    <div className="min-h-dvh bg-background text-foreground lg:grid lg:grid-cols-[220px_minmax(0,1fr)]">
      <aside className="border-b border-border bg-card lg:sticky lg:top-0 lg:flex lg:h-dvh lg:flex-col lg:border-r lg:border-b-0">
        <div className="px-4 py-4 lg:px-5 lg:pt-6">
          <p className="font-mono text-xs tracking-widest text-muted-foreground">FLEET YARD</p>
          <h1 className="text-xl font-semibold tracking-tight">Axlehouse</h1>
        </div>
        <nav className="flex gap-1 overflow-x-auto px-3 pb-3 lg:flex-col lg:overflow-visible lg:px-3" aria-label="Sections">
          {NAV.map((item) => {
            const Icon = item.icon;
            const active = view === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setView(item.id)}
                className={cn(
                  "flex h-11 shrink-0 items-center gap-2 rounded-md px-3 text-sm font-medium",
                  active ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted hover:text-foreground",
                )}
              >
                <Icon className="size-4" aria-hidden />
                {item.label}
              </button>
            );
          })}
        </nav>
        <p className="mt-auto hidden px-5 py-5 text-xs leading-relaxed text-muted-foreground lg:block">
          Records stay in this browser. Export a backup before you clear site data.
        </p>
      </aside>

      <div className="min-w-0">
        <header className="border-b border-border bg-background/90 px-4 py-4 sm:px-6">
          <div className="mx-auto flex max-w-5xl flex-col gap-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h2 className="text-2xl font-semibold tracking-tight">{current.label}</h2>
                <p className="text-sm text-muted-foreground">{current.blurb}</p>
              </div>
              <div className="flex shrink-0 gap-2">
                <Button variant="secondary" size="icon" aria-label="Export backup" onClick={exportBackup}>
                  <Download className="size-4" />
                </Button>
                <Button variant="secondary" size="icon" aria-label="Import backup" onClick={() => fileRef.current?.click()}>
                  <Upload className="size-4" />
                </Button>
                <Button className="hidden sm:inline-flex" onClick={primary.run}>
                  {primary.label}
                </Button>
              </div>
            </div>
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
              <label className="relative block min-w-0 flex-1">
                <span className="sr-only">Search trucks, VINs, plates, and spots</span>
                <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder="Search truck, VIN, plate, spot"
                  className="h-11 w-full rounded-md border border-border bg-card pr-3 pl-10 text-sm outline-none placeholder:text-muted-foreground/70 focus-visible:border-primary focus-visible:ring-2 focus-visible:ring-primary/20"
                />
              </label>
              <Button className="sm:hidden" onClick={primary.run}>
                {primary.label}
              </Button>
            </div>
            {notice ? (
              <p className="text-sm text-muted-foreground">
                {notice}{" "}
                <button type="button" className="font-medium text-foreground underline" onClick={() => setNotice("")}>
                  Dismiss
                </button>
              </p>
            ) : null}
          </div>
        </header>

        <main className="mx-auto max-w-5xl px-4 py-6 sm:px-6">
          <div key={view} className="rise">
            {view === "yard" ? <YardView query={query} onOpenTruck={(id) => setDialog({ type: "truck", id })} /> : null}
            {view === "trucks" ? (
              <TrucksView query={query} onOpenTruck={(id) => setDialog({ type: "truck", id })} onAdd={() => setDialog({ type: "truck" })} />
            ) : null}
            {view === "tires" ? (
              <TiresView
                query={query}
                onOpen={(id) => setDialog({ type: "tire", id })}
                onAdd={() => setDialog({ type: "tire" })}
              />
            ) : null}
            {view === "oil" ? (
              <OilView
                query={query}
                onOpen={(id) => setDialog({ type: "oil", id })}
                onAdd={() => setDialog({ type: "oil" })}
                onOpenTruck={(id) => setDialog({ type: "truck", id })}
              />
            ) : null}
            {view === "fees" ? (
              <FeesView
                query={query}
                onOpenTire={(id) => setDialog({ type: "tire", id })}
                onOpenOil={(id) => setDialog({ type: "oil", id })}
                onLogTire={() => setDialog({ type: "tire" })}
                onLogOil={() => setDialog({ type: "oil" })}
              />
            ) : null}
          </div>
          <footer className="mt-10 flex flex-col gap-3 border-t border-border pt-4 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
            <p>Saved on this device.</p>
            <div className="flex flex-wrap gap-2">
              <Button variant="ghost" size="sm" onClick={exportBackup}>
                Export backup
              </Button>
              <Button variant="ghost" size="sm" onClick={() => setConfirmSample(true)}>
                Load sample yard
              </Button>
            </div>
          </footer>
        </main>
      </div>

      <input
        ref={fileRef}
        type="file"
        accept="application/json,.json"
        className="sr-only"
        onChange={(event) => {
          const file = event.target.files?.[0];
          event.target.value = "";
          if (file) onFile(file);
        }}
      />

      <TruckDialog
        open={dialog?.type === "truck"}
        truckId={dialog?.type === "truck" ? dialog.id : undefined}
        onClose={() => setDialog(null)}
        onLogTire={(id) => setDialog({ type: "tire", truckId: id })}
        onLogOil={(id) => setDialog({ type: "oil", truckId: id })}
      />
      <TireDialog
        open={dialog?.type === "tire"}
        tireId={dialog?.type === "tire" ? dialog.id : undefined}
        truckId={dialog?.type === "tire" ? dialog.truckId : undefined}
        onClose={() => setDialog(null)}
      />
      <OilDialog
        open={dialog?.type === "oil"}
        oilId={dialog?.type === "oil" ? dialog.id : undefined}
        truckId={dialog?.type === "oil" ? dialog.truckId : undefined}
        onClose={() => setDialog(null)}
      />

      <Modal
        open={pendingImport !== null}
        onOpenChange={(open) => {
          if (!open) setPendingImport(null);
        }}
        title="Replace the yard?"
        description={
          pendingImport
            ? `This backup has ${pendingImport.trucks.length} trucks, ${pendingImport.tires.length} tire records, and ${pendingImport.oils.length} oil changes. Current records on this device will be overwritten.`
            : ""
        }
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="secondary" onClick={() => setPendingImport(null)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                if (pendingImport) {
                  useFleet.getState().importBackup(pendingImport);
                  setNotice(`Imported ${pendingImport.trucks.length} trucks.`);
                }
                setPendingImport(null);
              }}
            >
              Replace records
            </Button>
          </div>
        }
      >
        <p className="text-sm text-muted-foreground">Export a backup first if you still need what is here now.</p>
      </Modal>

      <Modal
        open={confirmSample}
        onOpenChange={setConfirmSample}
        title="Load the sample yard?"
        description="Replaces everything on this device with the Northline sample: eight trucks, tire fees, and oil changes."
        footer={
          <div className="flex justify-end gap-2">
            <Button variant="secondary" onClick={() => setConfirmSample(false)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              onClick={() => {
                useFleet.getState().resetDemo();
                setConfirmSample(false);
                setNotice("Sample yard loaded.");
              }}
            >
              Load sample
            </Button>
          </div>
        }
      >
        <p className="text-sm text-muted-foreground">Your current trucks, tires, and oil records will be removed from this browser.</p>
      </Modal>
    </div>
  );
}
