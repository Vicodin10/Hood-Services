import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { SelectInput } from "@/components/ui/field";
import { byNumber, includesQuery, tireDetail, truckLabel } from "@/lib/fleet/domain";
import { miles, money, shortDate } from "@/lib/fleet/format";
import { useFleet } from "@/lib/fleet/store";
import { FEE_KINDS } from "@/lib/fleet/types";

export function TiresView({
  query,
  onOpen,
  onAdd,
}: {
  query: string;
  onOpen: (id: string) => void;
  onAdd: () => void;
}) {
  const trucks = useFleet((s) => s.trucks);
  const tires = useFleet((s) => s.tires);
  const [truckId, setTruckId] = useState("all");
  const [kind, setKind] = useState("all");
  const truckMap = useMemo(() => new Map(trucks.map((truck) => [truck.id, truck])), [trucks]);

  const visible = tires
    .filter((tire) => (truckId === "all" ? true : tire.truckId === truckId))
    .filter((tire) => (kind === "all" ? true : tire.feeKind === kind))
    .filter((tire) => {
      const truck = truckMap.get(tire.truckId);
      return includesQuery(
        [truck?.number, truck?.plate, truck?.vin, truck?.spot, tire.brand, tire.size, tire.position, tire.action, tire.feeKind, tire.notes]
          .join(" ")
          .toLowerCase(),
        query,
      );
    })
    .sort((a, b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id));

  const total = visible.reduce((sum, tire) => sum + tire.fee, 0);
  const sortedTrucks = [...trucks].sort(byNumber);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h2 className="text-base font-semibold tracking-tight">Tire usage and fees</h2>
          <p className="text-sm text-muted-foreground">
            {visible.length} {visible.length === 1 ? "record" : "records"} · {money(total)}
          </p>
        </div>
        <Button onClick={onAdd}>Log tire</Button>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <SelectInput value={truckId} onChange={(e) => setTruckId(e.target.value)} aria-label="Filter by truck">
          <option value="all">All trucks</option>
          {sortedTrucks.map((truck) => (
            <option key={truck.id} value={truck.id}>
              Truck {truck.number}
            </option>
          ))}
        </SelectInput>
        <SelectInput value={kind} onChange={(e) => setKind(e.target.value)} aria-label="Filter by fee kind">
          <option value="all">All fee kinds</option>
          {FEE_KINDS.map((item) => (
            <option key={item}>{item}</option>
          ))}
        </SelectInput>
      </div>
      {visible.length === 0 ? (
        <p className="rounded-xl border border-dashed border-border px-4 py-10 text-center text-sm text-muted-foreground">
          {tires.length === 0 ? "No tire fees yet. Log a mount, repair, or disposal." : "Nothing matches those filters."}
        </p>
      ) : (
        <ul className="flex flex-col gap-2">
          {visible.map((tire) => {
            const truck = truckMap.get(tire.truckId);
            return (
              <li key={tire.id}>
                <button
                  type="button"
                  onClick={() => onOpen(tire.id)}
                  className="flex w-full items-start justify-between gap-3 rounded-lg border border-border bg-card px-4 py-3 text-left hover:bg-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30"
                >
                  <span className="min-w-0">
                    <span className="block font-medium">
                      {truckLabel(truck)} · {tire.feeKind}
                    </span>
                    <span className="mt-1 block text-sm text-muted-foreground">{tireDetail(tire)}</span>
                    <span className="mt-1 block font-mono text-xs text-muted-foreground tabular-nums">
                      {shortDate(tire.date)} · {miles(tire.mileage)}
                      {tire.tread ? ` · ${tire.tread}` : ""}
                    </span>
                  </span>
                  <span className="shrink-0 font-mono text-sm font-medium tabular-nums">{money(tire.fee)}</span>
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
