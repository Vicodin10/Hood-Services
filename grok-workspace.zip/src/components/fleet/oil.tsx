import { OilBadge } from "@/components/fleet/forms";
import { Button } from "@/components/ui/button";
import { attentionRank, byNumber, engineLine, includesQuery, oilDetail, oilStatus, truckLabel } from "@/lib/fleet/domain";
import { miles, money, shortDate } from "@/lib/fleet/format";
import { useFleet } from "@/lib/fleet/store";

export function OilView({
  query,
  onOpen,
  onAdd,
  onOpenTruck,
}: {
  query: string;
  onOpen: (id: string) => void;
  onAdd: () => void;
  onOpenTruck: (id: string) => void;
}) {
  const trucks = useFleet((s) => s.trucks);
  const oils = useFleet((s) => s.oils);
  const truckMap = new Map(trucks.map((truck) => [truck.id, truck]));
  const schedule = [...trucks]
    .map((truck) => ({ truck, oil: oilStatus(truck, oils) }))
    .filter((item) => includesQuery([item.truck.number, item.truck.plate, item.truck.vin, item.truck.spot, item.oil.label, item.oil.detail].join(" ").toLowerCase(), query))
    .sort((a, b) => attentionRank(a.oil.tone) - attentionRank(b.oil.tone) || byNumber(a.truck, b.truck));

  const history = [...oils]
    .filter((oil) => {
      const truck = truckMap.get(oil.truckId);
      return includesQuery(
        [truck?.number, truck?.plate, truck?.vin, oil.oilType, oil.vendor, oil.filter, oil.notes, oil.quantity].join(" ").toLowerCase(),
        query,
      );
    })
    .sort((a, b) => b.date.localeCompare(a.date));

  return (
    <div className="flex flex-col gap-8">
      <section className="flex flex-col gap-3">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h2 className="text-base font-semibold tracking-tight">Intervals</h2>
            <p className="text-sm text-muted-foreground">Compared with each truck’s odometer and today’s date.</p>
          </div>
          <Button onClick={onAdd}>Log oil</Button>
        </div>
        {schedule.length === 0 ? (
          <p className="rounded-xl border border-dashed border-border px-4 py-10 text-center text-sm text-muted-foreground">
            Add a truck to track oil changes.
          </p>
        ) : (
          <ul className="flex flex-col gap-2">
            {schedule.map(({ truck, oil }) => (
              <li key={truck.id}>
                <button
                  type="button"
                  onClick={() => onOpenTruck(truck.id)}
                  className="flex w-full items-start justify-between gap-3 rounded-lg border border-border bg-card px-4 py-3 text-left hover:bg-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30"
                >
                  <span className="min-w-0">
                    <span className="block font-medium">
                      Truck {truck.number}
                      <span className="font-normal text-muted-foreground"> · spot {truck.spot}</span>
                    </span>
                    <span className="mt-1 block truncate text-sm text-muted-foreground">{engineLine(truck)}</span>
                    <span className="mt-1 block text-sm text-muted-foreground">{oil.detail}</span>
                  </span>
                  <OilBadge tone={oil.tone} label={oil.label} />
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="flex flex-col gap-3">
        <h2 className="text-base font-semibold tracking-tight">Change history</h2>
        {history.length === 0 ? (
          <p className="text-sm text-muted-foreground">No oil changes logged.</p>
        ) : (
          <ul className="flex flex-col gap-2">
            {history.map((oil) => {
              const truck = truckMap.get(oil.truckId);
              return (
                <li key={oil.id}>
                  <button
                    type="button"
                    onClick={() => onOpen(oil.id)}
                    className="flex w-full items-start justify-between gap-3 rounded-lg border border-border bg-card px-4 py-3 text-left hover:bg-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30"
                  >
                    <span className="min-w-0">
                      <span className="block font-medium">{truckLabel(truck)}</span>
                      <span className="mt-1 block text-sm text-muted-foreground">{oilDetail(oil) || "Oil change"}</span>
                      <span className="mt-1 block font-mono text-xs text-muted-foreground tabular-nums">
                        {shortDate(oil.date)} · {miles(oil.mileage)}
                        {oil.nextDueMileage ? ` · next ${miles(oil.nextDueMileage)}` : ""}
                      </span>
                    </span>
                    <span className="shrink-0 font-mono text-sm font-medium tabular-nums">{money(oil.fee)}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </div>
  );
}
