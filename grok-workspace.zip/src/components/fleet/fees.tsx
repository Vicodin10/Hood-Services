import { useState, type ReactNode } from "react";
import { SpendChart } from "@/components/fleet/chart";
import { Button } from "@/components/ui/button";
import { includesQuery, monthlySpend, oilDetail, tireDetail, truckLabel } from "@/lib/fleet/domain";
import { money, shortDate } from "@/lib/fleet/format";
import { useFleet } from "@/lib/fleet/store";

type Kind = "all" | "tire" | "oil";

type Row = {
  id: string;
  date: string;
  truckId: string;
  kind: "Tire" | "Oil";
  detail: string;
  fee: number;
  source: "tire" | "oil";
};

export function FeesView({
  query,
  onOpenTire,
  onOpenOil,
  onLogTire,
  onLogOil,
}: {
  query: string;
  onOpenTire: (id: string) => void;
  onOpenOil: (id: string) => void;
  onLogTire: () => void;
  onLogOil: () => void;
}) {
  const trucks = useFleet((s) => s.trucks);
  const tires = useFleet((s) => s.tires);
  const oils = useFleet((s) => s.oils);
  const [kind, setKind] = useState<Kind>("all");
  const [range, setRange] = useState<"year" | "all">("year");
  const year = new Date().getFullYear();
  const truckMap = new Map(trucks.map((truck) => [truck.id, truck]));

  const rows: Row[] = [
    ...tires.map((tire) => ({
      id: tire.id,
      date: tire.date,
      truckId: tire.truckId,
      kind: "Tire" as const,
      detail: tireDetail(tire),
      fee: tire.fee,
      source: "tire" as const,
    })),
    ...oils.map((oil) => ({
      id: oil.id,
      date: oil.date,
      truckId: oil.truckId,
      kind: "Oil" as const,
      detail: oilDetail(oil) || "Oil change",
      fee: oil.fee,
      source: "oil" as const,
    })),
  ];

  const visible = rows
    .filter((row) => (range === "year" ? row.date.startsWith(`${year}-`) : true))
    .filter((row) => (kind === "all" ? true : row.source === kind))
    .filter((row) => {
      const truck = truckMap.get(row.truckId);
      return includesQuery([truck?.number, truck?.plate, truck?.vin, truck?.spot, row.kind, row.detail, row.date].join(" ").toLowerCase(), query);
    })
    .sort((a, b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id));

  const total = visible.reduce((sum, row) => sum + row.fee, 0);
  const tireTotal = visible.filter((row) => row.source === "tire").reduce((sum, row) => sum + row.fee, 0);
  const oilTotal = visible.filter((row) => row.source === "oil").reduce((sum, row) => sum + row.fee, 0);

  return (
    <div className="flex flex-col gap-5">
      <section className="rounded-xl border border-border bg-card p-4">
        <h2 className="text-base font-semibold tracking-tight">Ledger</h2>
        <p className="mt-1 font-mono text-2xl font-medium tabular-nums tracking-tight">{money(total)}</p>
        <p className="mt-1 text-sm text-muted-foreground">
          Tires {money(tireTotal)} · Oil {money(oilTotal)}
          {range === "year" ? ` · ${year}` : " · all dates"}
        </p>
        <div className="mt-4">
          <SpendChart data={monthlySpend(tires, oils)} />
        </div>
      </section>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap gap-2">
          <Filter active={kind === "all"} onClick={() => setKind("all")}>
            All
          </Filter>
          <Filter active={kind === "tire"} onClick={() => setKind("tire")}>
            Tires
          </Filter>
          <Filter active={kind === "oil"} onClick={() => setKind("oil")}>
            Oil
          </Filter>
          <Filter active={range === "year"} onClick={() => setRange("year")}>
            {year}
          </Filter>
          <Filter active={range === "all"} onClick={() => setRange("all")}>
            All time
          </Filter>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={onLogOil}>
            Log oil
          </Button>
          <Button onClick={onLogTire}>Log tire</Button>
        </div>
      </div>

      {visible.length === 0 ? (
        <p className="rounded-xl border border-dashed border-border px-4 py-10 text-center text-sm text-muted-foreground">
          No fees in this view.
        </p>
      ) : (
        <ul className="flex flex-col gap-2">
          {visible.map((row) => {
            const truck = truckMap.get(row.truckId);
            return (
              <li key={`${row.source}-${row.id}`}>
                <button
                  type="button"
                  onClick={() => (row.source === "tire" ? onOpenTire(row.id) : onOpenOil(row.id))}
                  className="flex w-full items-start justify-between gap-3 rounded-lg border border-border bg-card px-4 py-3 text-left hover:bg-muted/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30"
                >
                  <span className="min-w-0">
                    <span className="block font-medium">
                      {truckLabel(truck)} · {row.kind}
                    </span>
                    <span className="mt-1 block truncate text-sm text-muted-foreground">{row.detail}</span>
                    <span className="mt-1 block font-mono text-xs text-muted-foreground">{shortDate(row.date)}</span>
                  </span>
                  <span className="shrink-0 font-mono text-sm font-medium tabular-nums">{money(row.fee)}</span>
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function Filter({ active, onClick, children }: { active: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        active
          ? "h-9 rounded-full bg-primary px-3 text-sm font-medium text-primary-foreground"
          : "h-9 rounded-full border border-border bg-card px-3 text-sm font-medium text-foreground hover:bg-muted"
      }
    >
      {children}
    </button>
  );
}
