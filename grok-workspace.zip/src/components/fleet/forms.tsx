import { useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Field, SelectInput, TextArea, TextInput } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";
import { engineLine, oilDetail, spendForTruck, tireDetail, truckLabel } from "@/lib/fleet/domain";
import { addDaysISO, money, parseMiles, parseMoney, shortDate, todayISO } from "@/lib/fleet/format";
import { useFleet } from "@/lib/fleet/store";
import {
  FEE_KINDS,
  STATUS_LABEL,
  TIRE_ACTIONS,
  TIRE_POSITIONS,
  TRUCK_STATUSES,
  type TruckStatus,
} from "@/lib/fleet/types";

type TruckDraft = {
  number: string;
  vin: string;
  plate: string;
  spot: string;
  year: string;
  make: string;
  model: string;
  engineSize: string;
  engineDetails: string;
  odometer: string;
  status: TruckStatus;
  notes: string;
};

type TireDraft = {
  truckId: string;
  date: string;
  position: string;
  action: string;
  brand: string;
  size: string;
  tread: string;
  mileage: string;
  fee: string;
  feeKind: string;
  notes: string;
};

type OilDraft = {
  truckId: string;
  date: string;
  mileage: string;
  nextDueMileage: string;
  nextDueDate: string;
  oilType: string;
  quantity: string;
  filter: string;
  fee: string;
  vendor: string;
  notes: string;
};

function emptyTruck(): TruckDraft {
  return {
    number: "",
    vin: "",
    plate: "",
    spot: "",
    year: "",
    make: "",
    model: "",
    engineSize: "",
    engineDetails: "",
    odometer: "",
    status: "in-service",
    notes: "",
  };
}

function emptyTire(truckId = ""): TireDraft {
  const truck = useFleet.getState().trucks.find((item) => item.id === truckId);
  return {
    truckId,
    date: todayISO(),
    position: TIRE_POSITIONS[0],
    action: TIRE_ACTIONS[0],
    brand: "",
    size: "295/75R22.5",
    tread: "",
    mileage: truck ? String(truck.odometer) : "",
    fee: "",
    feeKind: FEE_KINDS[0],
    notes: "",
  };
}

function emptyOil(truckId = ""): OilDraft {
  const truck = useFleet.getState().trucks.find((item) => item.id === truckId);
  const mileage = truck ? truck.odometer : 0;
  return {
    truckId,
    date: todayISO(),
    mileage: truck ? String(truck.odometer) : "",
    nextDueMileage: truck ? String(mileage + 25000) : "",
    nextDueDate: addDaysISO(180),
    oilType: "15W-40 CK-4",
    quantity: "10 gal",
    filter: "",
    fee: "",
    vendor: "",
    notes: "",
  };
}

function FormError({ message }: { message: string }) {
  if (!message) return null;
  return (
    <p role="alert" className="text-sm text-destructive">
      {message}
    </p>
  );
}

export function TruckDialog({
  open,
  truckId,
  onClose,
  onLogTire,
  onLogOil,
}: {
  open: boolean;
  truckId?: string;
  onClose: () => void;
  onLogTire: (truckId: string) => void;
  onLogOil: (truckId: string) => void;
}) {
  const trucks = useFleet((s) => s.trucks);
  const tires = useFleet((s) => s.tires);
  const oils = useFleet((s) => s.oils);
  const addTruck = useFleet((s) => s.addTruck);
  const updateTruck = useFleet((s) => s.updateTruck);
  const removeTruck = useFleet((s) => s.removeTruck);
  const [draft, setDraft] = useState<TruckDraft>(emptyTruck);
  const [error, setError] = useState("");
  const [confirming, setConfirming] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!open) return;
    const current = useFleet.getState().trucks.find((truck) => truck.id === truckId);
    setError("");
    setConfirming(false);
    setCopied(false);
    setDraft(
      current
        ? {
            number: current.number,
            vin: current.vin,
            plate: current.plate,
            spot: current.spot,
            year: current.year,
            make: current.make,
            model: current.model,
            engineSize: current.engineSize,
            engineDetails: current.engineDetails,
            odometer: String(current.odometer),
            status: current.status,
            notes: current.notes,
          }
        : emptyTruck(),
    );
  }, [open, truckId]);

  const truckTires = tires
    .filter((tire) => tire.truckId === truckId)
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 4);
  const truckOils = oils
    .filter((oil) => oil.truckId === truckId)
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 3);
  const spend = truckId ? spendForTruck(tires, oils, truckId) : null;

  function set<K extends keyof TruckDraft>(key: K, value: TruckDraft[K]) {
    setDraft((prev) => ({ ...prev, [key]: value }));
  }

  function save() {
    const number = draft.number.trim();
    const vin = draft.vin.toUpperCase().replace(/\s+/g, "");
    const plate = draft.plate.toUpperCase().trim();
    const spot = draft.spot.trim();
    const engineSize = draft.engineSize.trim();
    const odometer = parseMiles(draft.odometer);
    if (!number || !vin || !plate || !spot || !engineSize) {
      setError("Truck number, VIN, plate, spot, and engine size are required.");
      return;
    }
    if (odometer === null || odometer < 0) {
      setError("Enter the odometer as a number.");
      return;
    }
    const numberClash = trucks.some(
      (truck) => truck.id !== truckId && truck.number.trim().toLowerCase() === number.toLowerCase(),
    );
    if (numberClash) {
      setError("That truck number is already in the yard.");
      return;
    }
    const vinClash = trucks.some((truck) => truck.id !== truckId && truck.vin.toUpperCase() === vin);
    if (vinClash) {
      setError("That VIN is already on another truck.");
      return;
    }
    const payload = {
      number,
      vin,
      plate,
      spot,
      year: draft.year.trim(),
      make: draft.make.trim(),
      model: draft.model.trim(),
      engineSize,
      engineDetails: draft.engineDetails.trim(),
      odometer,
      status: draft.status,
      notes: draft.notes.trim(),
    };
    if (truckId) updateTruck(truckId, payload);
    else addTruck(payload);
    onClose();
  }

  async function copyVin() {
    if (!draft.vin.trim()) return;
    try {
      await navigator.clipboard.writeText(draft.vin.toUpperCase().replace(/\s+/g, ""));
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1200);
    } catch {
      setCopied(false);
    }
  }

  return (
    <Modal
      open={open}
      onOpenChange={(next) => {
        if (!next) onClose();
      }}
      wide
      title={truckId ? `Truck ${draft.number || ""}`.trim() : "Add truck"}
      description="Number, VIN, plate, spot, and engine stay with the unit."
      footer={
        confirming ? (
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm text-muted-foreground">Remove this truck and its tire and oil records?</p>
            <div className="flex gap-2">
              <Button variant="secondary" onClick={() => setConfirming(false)}>
                Cancel
              </Button>
              <Button
                variant="danger"
                onClick={() => {
                  if (truckId) removeTruck(truckId);
                  onClose();
                }}
              >
                Remove
              </Button>
            </div>
          </div>
        ) : (
          <div className="flex flex-col-reverse gap-2 sm:flex-row sm:items-center sm:justify-between">
            {truckId ? (
              <Button variant="ghost" className="text-destructive hover:bg-destructive/10" onClick={() => setConfirming(true)}>
                Remove truck
              </Button>
            ) : (
              <span />
            )}
            <div className="flex gap-2">
              <Button variant="secondary" onClick={onClose}>
                Cancel
              </Button>
              <Button onClick={save}>Save truck</Button>
            </div>
          </div>
        )
      }
    >
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Truck number">
          <TextInput value={draft.number} onChange={(e) => set("number", e.target.value)} placeholder="214" />
        </Field>
        <Field label="Spot number">
          <TextInput value={draft.spot} onChange={(e) => set("spot", e.target.value)} placeholder="12" />
        </Field>
        <Field label="Plate">
          <TextInput value={draft.plate} onChange={(e) => set("plate", e.target.value)} placeholder="NL-2148" className="font-mono uppercase" />
        </Field>
        <Field label="Status">
          <SelectInput value={draft.status} onChange={(e) => set("status", e.target.value as TruckStatus)}>
            {TRUCK_STATUSES.map((status) => (
              <option key={status} value={status}>
                {STATUS_LABEL[status]}
              </option>
            ))}
          </SelectInput>
        </Field>
        <Field label="VIN" hint="Usually 17 characters. Stored as entered if it is shorter." className="sm:col-span-2">
          <div className="flex gap-2">
            <TextInput
              value={draft.vin}
              onChange={(e) => set("vin", e.target.value)}
              placeholder="1FUJGLDR5PLNA4821"
              className="font-mono uppercase"
            />
            <Button variant="secondary" onClick={() => void copyVin()} disabled={!draft.vin.trim()}>
              {copied ? "Copied" : "Copy"}
            </Button>
          </div>
        </Field>
        <Field label="Year">
          <TextInput value={draft.year} onChange={(e) => set("year", e.target.value)} inputMode="numeric" placeholder="2023" />
        </Field>
        <Field label="Odometer">
          <TextInput value={draft.odometer} onChange={(e) => set("odometer", e.target.value)} inputMode="numeric" placeholder="412880" />
        </Field>
        <Field label="Make">
          <TextInput value={draft.make} onChange={(e) => set("make", e.target.value)} placeholder="Freightliner" />
        </Field>
        <Field label="Model">
          <TextInput value={draft.model} onChange={(e) => set("model", e.target.value)} placeholder="Cascadia" />
        </Field>
        <Field label="Engine size">
          <TextInput value={draft.engineSize} onChange={(e) => set("engineSize", e.target.value)} placeholder="15.0 L" />
        </Field>
        <Field label="Engine details" className="sm:col-span-2">
          <TextInput
            value={draft.engineDetails}
            onChange={(e) => set("engineDetails", e.target.value)}
            placeholder="Cummins X15, 450 hp, 1,850 lb-ft"
          />
        </Field>
        <Field label="Notes" className="sm:col-span-2">
          <TextArea value={draft.notes} onChange={(e) => set("notes", e.target.value)} placeholder="Shop holds, spec tires, lease notes" />
        </Field>
      </div>
      <div className="mt-3">
        <FormError message={error} />
      </div>
      {truckId && spend ? (
        <div className="mt-5 border-t border-border pt-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="text-sm font-medium">Service on this truck</h3>
            <p className="font-mono text-xs text-muted-foreground tabular-nums">
              Tires {money(spend.tire)} · Oil {money(spend.oil)}
            </p>
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <Button variant="secondary" size="sm" onClick={() => onLogTire(truckId)}>
              Log tire
            </Button>
            <Button variant="secondary" size="sm" onClick={() => onLogOil(truckId)}>
              Log oil
            </Button>
          </div>
          <ul className="mt-3 flex flex-col gap-2">
            {truckOils.map((oil) => (
              <li key={oil.id} className="text-sm">
                <span className="text-muted-foreground">{shortDate(oil.date)} · Oil · </span>
                {oilDetail(oil) || "Change"} · <span className="font-mono tabular-nums">{money(oil.fee)}</span>
              </li>
            ))}
            {truckTires.map((tire) => (
              <li key={tire.id} className="text-sm">
                <span className="text-muted-foreground">{shortDate(tire.date)} · Tire · </span>
                {tireDetail(tire)} · <span className="font-mono tabular-nums">{money(tire.fee)}</span>
              </li>
            ))}
            {truckOils.length === 0 && truckTires.length === 0 ? (
              <li className="text-sm text-muted-foreground">No tire or oil records yet.</li>
            ) : null}
          </ul>
        </div>
      ) : null}
    </Modal>
  );
}

export function TireDialog({
  open,
  tireId,
  truckId,
  onClose,
}: {
  open: boolean;
  tireId?: string;
  truckId?: string;
  onClose: () => void;
}) {
  const trucks = useFleet((s) => s.trucks);
  const addTire = useFleet((s) => s.addTire);
  const updateTire = useFleet((s) => s.updateTire);
  const removeTire = useFleet((s) => s.removeTire);
  const [draft, setDraft] = useState<TireDraft>(emptyTire());
  const [error, setError] = useState("");
  const [confirming, setConfirming] = useState(false);

  useEffect(() => {
    if (!open) return;
    const current = useFleet.getState().tires.find((tire) => tire.id === tireId);
    setError("");
    setConfirming(false);
    setDraft(
      current
        ? {
            truckId: current.truckId,
            date: current.date,
            position: current.position,
            action: current.action,
            brand: current.brand,
            size: current.size,
            tread: current.tread,
            mileage: String(current.mileage),
            fee: String(current.fee),
            feeKind: current.feeKind,
            notes: current.notes,
          }
        : emptyTire(truckId),
    );
  }, [open, tireId, truckId]);

  function set<K extends keyof TireDraft>(key: K, value: TireDraft[K]) {
    setDraft((prev) => ({ ...prev, [key]: value }));
  }

  function save() {
    if (!draft.truckId) {
      setError("Choose a truck first.");
      return;
    }
    if (!draft.date) {
      setError("Enter the date.");
      return;
    }
    const fee = parseMoney(draft.fee);
    const mileage = parseMiles(draft.mileage);
    if (fee === null || fee < 0) {
      setError("Enter the fee. Use 0 if there was no charge.");
      return;
    }
    if (mileage === null || mileage < 0) {
      setError("Enter the mileage.");
      return;
    }
    const payload = {
      truckId: draft.truckId,
      date: draft.date,
      position: draft.position,
      action: draft.action,
      brand: draft.brand.trim(),
      size: draft.size.trim(),
      tread: draft.tread.trim(),
      mileage,
      fee,
      feeKind: draft.feeKind,
      notes: draft.notes.trim(),
    };
    if (tireId) updateTire(tireId, payload);
    else addTire(payload);
    onClose();
  }

  const sorted = [...trucks].sort((a, b) => a.number.localeCompare(b.number, undefined, { numeric: true }));

  return (
    <Modal
      open={open}
      onOpenChange={(next) => {
        if (!next) onClose();
      }}
      title={tireId ? "Edit tire record" : "Log tire usage"}
      description="Mounts, repairs, rotations, and the fee for each."
      footer={
        confirming ? (
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm text-muted-foreground">Remove this tire record?</p>
            <div className="flex gap-2">
              <Button variant="secondary" onClick={() => setConfirming(false)}>
                Cancel
              </Button>
              <Button
                variant="danger"
                onClick={() => {
                  if (tireId) removeTire(tireId);
                  onClose();
                }}
              >
                Remove
              </Button>
            </div>
          </div>
        ) : (
          <div className="flex flex-col-reverse gap-2 sm:flex-row sm:items-center sm:justify-between">
            {tireId ? (
              <Button variant="ghost" className="text-destructive hover:bg-destructive/10" onClick={() => setConfirming(true)}>
                Remove
              </Button>
            ) : (
              <span />
            )}
            <div className="flex gap-2">
              <Button variant="secondary" onClick={onClose}>
                Cancel
              </Button>
              <Button onClick={save} disabled={trucks.length === 0}>
                Save tire
              </Button>
            </div>
          </div>
        )
      }
    >
      {trucks.length === 0 ? (
        <p className="text-sm text-muted-foreground">Add a truck before logging tires.</p>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Truck" className="sm:col-span-2">
            <SelectInput
              value={draft.truckId}
              onChange={(e) => {
                const nextId = e.target.value;
                const truck = trucks.find((item) => item.id === nextId);
                setDraft((prev) => ({
                  ...prev,
                  truckId: nextId,
                  mileage: !tireId && truck ? String(truck.odometer) : prev.mileage,
                }));
              }}
            >
              <option value="">Select a truck</option>
              {sorted.map((truck) => (
                <option key={truck.id} value={truck.id}>
                  {truck.number} · spot {truck.spot} · {truck.plate}
                </option>
              ))}
            </SelectInput>
          </Field>
          <Field label="Date">
            <TextInput type="date" value={draft.date} onChange={(e) => set("date", e.target.value)} />
          </Field>
          <Field label="Odometer">
            <TextInput value={draft.mileage} onChange={(e) => set("mileage", e.target.value)} inputMode="numeric" />
          </Field>
          <Field label="Position">
            <SelectInput value={draft.position} onChange={(e) => set("position", e.target.value)}>
              {TIRE_POSITIONS.map((position) => (
                <option key={position}>{position}</option>
              ))}
              {draft.position && !TIRE_POSITIONS.includes(draft.position as (typeof TIRE_POSITIONS)[number]) ? (
                <option>{draft.position}</option>
              ) : null}
            </SelectInput>
          </Field>
          <Field label="What happened">
            <SelectInput value={draft.action} onChange={(e) => set("action", e.target.value)}>
              {TIRE_ACTIONS.map((action) => (
                <option key={action}>{action}</option>
              ))}
            </SelectInput>
          </Field>
          <Field label="Brand">
            <TextInput value={draft.brand} onChange={(e) => set("brand", e.target.value)} placeholder="Michelin" />
          </Field>
          <Field label="Size">
            <TextInput value={draft.size} onChange={(e) => set("size", e.target.value)} placeholder="295/75R22.5" />
          </Field>
          <Field label="Tread left" hint="Optional, in 32nds.">
            <TextInput value={draft.tread} onChange={(e) => set("tread", e.target.value)} placeholder="14/32" />
          </Field>
          <Field label="Fee kind">
            <SelectInput value={draft.feeKind} onChange={(e) => set("feeKind", e.target.value)}>
              {FEE_KINDS.map((kind) => (
                <option key={kind}>{kind}</option>
              ))}
            </SelectInput>
          </Field>
          <Field label="Fee">
            <TextInput value={draft.fee} onChange={(e) => set("fee", e.target.value)} inputMode="decimal" placeholder="0.00" />
          </Field>
          <Field label="Notes" className="sm:col-span-2">
            <TextArea value={draft.notes} onChange={(e) => set("notes", e.target.value)} />
          </Field>
          <div className="sm:col-span-2">
            <FormError message={error} />
          </div>
        </div>
      )}
    </Modal>
  );
}

export function OilDialog({
  open,
  oilId,
  truckId,
  onClose,
}: {
  open: boolean;
  oilId?: string;
  truckId?: string;
  onClose: () => void;
}) {
  const trucks = useFleet((s) => s.trucks);
  const addOil = useFleet((s) => s.addOil);
  const updateOil = useFleet((s) => s.updateOil);
  const removeOil = useFleet((s) => s.removeOil);
  const [draft, setDraft] = useState<OilDraft>(emptyOil());
  const [error, setError] = useState("");
  const [confirming, setConfirming] = useState(false);

  useEffect(() => {
    if (!open) return;
    const current = useFleet.getState().oils.find((oil) => oil.id === oilId);
    setError("");
    setConfirming(false);
    setDraft(
      current
        ? {
            truckId: current.truckId,
            date: current.date,
            mileage: String(current.mileage),
            nextDueMileage: String(current.nextDueMileage),
            nextDueDate: current.nextDueDate,
            oilType: current.oilType,
            quantity: current.quantity,
            filter: current.filter,
            fee: String(current.fee),
            vendor: current.vendor,
            notes: current.notes,
          }
        : emptyOil(truckId),
    );
  }, [open, oilId, truckId]);

  function set<K extends keyof OilDraft>(key: K, value: OilDraft[K]) {
    setDraft((prev) => ({ ...prev, [key]: value }));
  }

  function save() {
    if (!draft.truckId) {
      setError("Choose a truck first.");
      return;
    }
    if (!draft.date) {
      setError("Enter the date.");
      return;
    }
    const mileage = parseMiles(draft.mileage);
    const nextDueMileage = parseMiles(draft.nextDueMileage || "0");
    const fee = parseMoney(draft.fee);
    if (mileage === null || mileage < 0) {
      setError("Enter the mileage at the change.");
      return;
    }
    if (nextDueMileage === null || nextDueMileage < 0) {
      setError("Enter the next due mileage, or 0 if you are not tracking it.");
      return;
    }
    if (fee === null || fee < 0) {
      setError("Enter the fee. Use 0 if there was no charge.");
      return;
    }
    const payload = {
      truckId: draft.truckId,
      date: draft.date,
      mileage,
      nextDueMileage,
      nextDueDate: draft.nextDueDate,
      oilType: draft.oilType.trim(),
      quantity: draft.quantity.trim(),
      filter: draft.filter.trim(),
      fee,
      vendor: draft.vendor.trim(),
      notes: draft.notes.trim(),
    };
    if (oilId) updateOil(oilId, payload);
    else addOil(payload);
    onClose();
  }

  const sorted = [...trucks].sort((a, b) => a.number.localeCompare(b.number, undefined, { numeric: true }));
  const selected = trucks.find((truck) => truck.id === draft.truckId);

  return (
    <Modal
      open={open}
      onOpenChange={(next) => {
        if (!next) onClose();
      }}
      title={oilId ? "Edit oil change" : "Log oil change"}
      description={selected ? `${truckLabel(selected)} · ${engineLine(selected)}` : "Interval, oil, and the shop fee."}
      footer={
        confirming ? (
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm text-muted-foreground">Remove this oil change?</p>
            <div className="flex gap-2">
              <Button variant="secondary" onClick={() => setConfirming(false)}>
                Cancel
              </Button>
              <Button
                variant="danger"
                onClick={() => {
                  if (oilId) removeOil(oilId);
                  onClose();
                }}
              >
                Remove
              </Button>
            </div>
          </div>
        ) : (
          <div className="flex flex-col-reverse gap-2 sm:flex-row sm:items-center sm:justify-between">
            {oilId ? (
              <Button variant="ghost" className="text-destructive hover:bg-destructive/10" onClick={() => setConfirming(true)}>
                Remove
              </Button>
            ) : (
              <span />
            )}
            <div className="flex gap-2">
              <Button variant="secondary" onClick={onClose}>
                Cancel
              </Button>
              <Button onClick={save} disabled={trucks.length === 0}>
                Save oil change
              </Button>
            </div>
          </div>
        )
      }
    >
      {trucks.length === 0 ? (
        <p className="text-sm text-muted-foreground">Add a truck before logging oil.</p>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Truck" className="sm:col-span-2">
            <SelectInput
              value={draft.truckId}
              onChange={(e) => {
                const nextId = e.target.value;
                const truck = trucks.find((item) => item.id === nextId);
                setDraft((prev) => ({
                  ...prev,
                  truckId: nextId,
                  mileage: !oilId && truck ? String(truck.odometer) : prev.mileage,
                  nextDueMileage: !oilId && truck ? String(truck.odometer + 25000) : prev.nextDueMileage,
                }));
              }}
            >
              <option value="">Select a truck</option>
              {sorted.map((truck) => (
                <option key={truck.id} value={truck.id}>
                  {truck.number} · spot {truck.spot} · {truck.plate}
                </option>
              ))}
            </SelectInput>
          </Field>
          <Field label="Date">
            <TextInput type="date" value={draft.date} onChange={(e) => set("date", e.target.value)} />
          </Field>
          <Field label="Mileage">
            <TextInput value={draft.mileage} onChange={(e) => set("mileage", e.target.value)} inputMode="numeric" />
          </Field>
          <Field label="Next due mileage" hint="Blank interval uses 25,000 miles on a new record.">
            <TextInput value={draft.nextDueMileage} onChange={(e) => set("nextDueMileage", e.target.value)} inputMode="numeric" />
          </Field>
          <Field label="Next due date">
            <TextInput type="date" value={draft.nextDueDate} onChange={(e) => set("nextDueDate", e.target.value)} />
          </Field>
          <Field label="Oil">
            <TextInput value={draft.oilType} onChange={(e) => set("oilType", e.target.value)} placeholder="15W-40 CK-4" />
          </Field>
          <Field label="Quantity">
            <TextInput value={draft.quantity} onChange={(e) => set("quantity", e.target.value)} placeholder="10 gal" />
          </Field>
          <Field label="Filter">
            <TextInput value={draft.filter} onChange={(e) => set("filter", e.target.value)} placeholder="Fleetguard LF14000NN" />
          </Field>
          <Field label="Fee">
            <TextInput value={draft.fee} onChange={(e) => set("fee", e.target.value)} inputMode="decimal" placeholder="0.00" />
          </Field>
          <Field label="Shop or vendor" className="sm:col-span-2">
            <TextInput value={draft.vendor} onChange={(e) => set("vendor", e.target.value)} placeholder="Northline shop" />
          </Field>
          <Field label="Notes" className="sm:col-span-2">
            <TextArea value={draft.notes} onChange={(e) => set("notes", e.target.value)} />
          </Field>
          <div className="sm:col-span-2">
            <FormError message={error} />
          </div>
        </div>
      )}
    </Modal>
  );
}

export function StatusBadge({ status }: { status: TruckStatus }) {
  const tone = status === "in-service" ? "good" : status === "shop" ? "warn" : "neutral";
  return <Badge tone={tone}>{STATUS_LABEL[status]}</Badge>;
}

export function OilBadge({ tone, label }: { tone: "good" | "warn" | "bad"; label: string }) {
  return <Badge tone={tone}>{label}</Badge>;
}
