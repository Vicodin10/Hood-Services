import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { MonthPoint } from "@/lib/fleet/domain";
import { money } from "@/lib/fleet/format";

function axisMoney(value: number) {
  if (Math.abs(value) >= 1000) {
    const compact = value / 1000;
    const digits = Math.abs(compact) >= 10 ? 0 : 1;
    return `$${compact.toFixed(digits)}k`;
  }
  return `$${Math.round(value)}`;
}

export function SpendChartInner({ data }: { data: MonthPoint[] }) {
  return (
    <div className="h-52 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 0, left: 0, bottom: 0 }} barGap={2} barCategoryGap="28%">
          <CartesianGrid vertical={false} stroke="var(--color-border)" />
          <XAxis
            dataKey="label"
            axisLine={false}
            tickLine={false}
            tick={{ fill: "var(--color-muted-foreground)", fontSize: 12 }}
          />
          <YAxis
            axisLine={false}
            tickLine={false}
            width={48}
            tick={{ fill: "var(--color-muted-foreground)", fontSize: 12 }}
            tickFormatter={axisMoney}
          />
          <Tooltip
            cursor={{ fill: "var(--color-muted)" }}
            content={({ active, payload, label }) => {
              if (!active || !payload?.length) return null;
              return (
                <div className="rounded-md border border-border bg-card px-3 py-2 text-xs shadow-sm">
                  <div className="mb-1 font-medium text-foreground">{label}</div>
                  {payload.map((item) => (
                    <div key={String(item.name)} className="flex justify-between gap-4 text-muted-foreground">
                      <span>{item.name}</span>
                      <span className="font-mono text-foreground tabular-nums">{money(Number(item.value ?? 0))}</span>
                    </div>
                  ))}
                </div>
              );
            }}
          />
          <Bar dataKey="tires" name="Tires" fill="var(--color-primary)" radius={[4, 4, 0, 0]} />
          <Bar dataKey="oil" name="Oil" fill="var(--color-muted-foreground)" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
