import { createFileRoute } from "@tanstack/react-router";
import { FleetApp } from "@/components/fleet/app";

export const Route = createFileRoute("/")({ component: FleetApp });
