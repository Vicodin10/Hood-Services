export const TRUCK_STATUSES = ["in-service", "shop", "parked"] as const;
export type TruckStatus = (typeof TRUCK_STATUSES)[number];

export const STATUS_LABEL: Record<TruckStatus, string> = {
  "in-service": "In service",
  shop: "In shop",
  parked: "Parked",
};

export const TIRE_POSITIONS = [
  "LF · steer",
  "RF · steer",
  "1LO · drive",
  "1LI · drive",
  "1RO · drive",
  "1RI · drive",
  "2LO · drive",
  "2LI · drive",
  "2RO · drive",
  "2RI · drive",
  "Spare",
  "Drive axles",
  "Other",
] as const;

export const TIRE_ACTIONS = ["Mounted", "Replaced", "Rotated", "Repaired", "Retreaded", "Disposed"] as const;

export const FEE_KINDS = ["Tire", "Labor", "Repair", "Retread", "Disposal", "Other"] as const;

export type Truck = {
  id: string;
  number: string;
  vin: string;
  plate: string;
  spot: string;
  year: string;
  make: string;
  model: string;
  engineSize: string;
  engineDetails: string;
  odometer: number;
  status: TruckStatus;
  notes: string;
};

export type TireEvent = {
  id: string;
  truckId: string;
  date: string;
  position: string;
  action: string;
  brand: string;
  size: string;
  tread: string;
  mileage: number;
  fee: number;
  feeKind: string;
  notes: string;
};

export type OilChange = {
  id: string;
  truckId: string;
  date: string;
  mileage: number;
  nextDueMileage: number;
  nextDueDate: string;
  oilType: string;
  quantity: string;
  filter: string;
  fee: number;
  vendor: string;
  notes: string;
};

export type FleetBackup = {
  trucks: Truck[];
  tires: TireEvent[];
  oils: OilChange[];
};
