import { create } from "zustand";
import { persist } from "zustand/middleware";
import { seedOils, seedTires, seedTrucks } from "@/lib/fleet/seed";
import type { FleetBackup, OilChange, TireEvent, Truck, TruckStatus } from "@/lib/fleet/types";
import { TRUCK_STATUSES } from "@/lib/fleet/types";

type TruckInput = Omit<Truck, "id">;
type TireInput = Omit<TireEvent, "id">;
type OilInput = Omit<OilChange, "id">;

type FleetState = FleetBackup & {
  addTruck: (input: TruckInput) => string;
  updateTruck: (id: string, patch: Partial<TruckInput>) => void;
  removeTruck: (id: string) => void;
  addTire: (input: TireInput) => string;
  updateTire: (id: string, patch: Partial<TireInput>) => void;
  removeTire: (id: string) => void;
  addOil: (input: OilInput) => string;
  updateOil: (id: string, patch: Partial<OilInput>) => void;
  removeOil: (id: string) => void;
  importBackup: (data: FleetBackup) => void;
  resetDemo: () => void;
};

function uid() {
  return crypto.randomUUID();
}

function bump(trucks: Truck[], truckId: string, mileage: number) {
  if (!Number.isFinite(mileage) || mileage <= 0) return trucks;
  return trucks.map((truck) =>
    truck.id === truckId && mileage > truck.odometer ? { ...truck, odometer: mileage } : truck,
  );
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object";
}

function str(value: unknown) {
  return typeof value === "string" ? value : "";
}

function num(value: unknown) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function isStatus(value: string): value is TruckStatus {
  return (TRUCK_STATUSES as readonly string[]).includes(value);
}

export function parseBackup(raw: unknown): FleetBackup | null {
  if (!isRecord(raw) || !Array.isArray(raw.trucks) || !Array.isArray(raw.tires) || !Array.isArray(raw.oils)) {
    return null;
  }

  const trucks: Truck[] = [];
  for (const item of raw.trucks) {
    if (!isRecord(item)) return null;
    const status = str(item.status);
    const odometer = num(item.odometer);
    const id = str(item.id);
    if (!id || !isStatus(status) || odometer === null) return null;
    trucks.push({
      id,
      number: str(item.number),
      vin: str(item.vin),
      plate: str(item.plate),
      spot: str(item.spot),
      year: str(item.year),
      make: str(item.make),
      model: str(item.model),
      engineSize: str(item.engineSize),
      engineDetails: str(item.engineDetails),
      odometer,
      status,
      notes: str(item.notes),
    });
  }

  const tires: TireEvent[] = [];
  for (const item of raw.tires) {
    if (!isRecord(item)) return null;
    const fee = num(item.fee);
    const mileage = num(item.mileage);
    const id = str(item.id);
    const truckId = str(item.truckId);
    if (!id || !truckId || fee === null || mileage === null) return null;
    tires.push({
      id,
      truckId,
      date: str(item.date),
      position: str(item.position),
      action: str(item.action),
      brand: str(item.brand),
      size: str(item.size),
      tread: str(item.tread),
      mileage,
      fee,
      feeKind: str(item.feeKind),
      notes: str(item.notes),
    });
  }

  const oils: OilChange[] = [];
  for (const item of raw.oils) {
    if (!isRecord(item)) return null;
    const fee = num(item.fee);
    const mileage = num(item.mileage);
    const nextDueMileage = num(item.nextDueMileage);
    const id = str(item.id);
    const truckId = str(item.truckId);
    if (!id || !truckId || fee === null || mileage === null || nextDueMileage === null) return null;
    oils.push({
      id,
      truckId,
      date: str(item.date),
      mileage,
      nextDueMileage,
      nextDueDate: str(item.nextDueDate),
      oilType: str(item.oilType),
      quantity: str(item.quantity),
      filter: str(item.filter),
      fee,
      vendor: str(item.vendor),
      notes: str(item.notes),
    });
  }

  return { trucks, tires, oils };
}

const demo = () => ({
  trucks: seedTrucks,
  tires: seedTires,
  oils: seedOils,
});

export const useFleet = create<FleetState>()(
  persist(
    (set) => ({
      ...demo(),
      addTruck: (input) => {
        const id = uid();
        set((s) => ({ trucks: [...s.trucks, { ...input, id }] }));
        return id;
      },
      updateTruck: (id, patch) =>
        set((s) => ({
          trucks: s.trucks.map((truck) => (truck.id === id ? { ...truck, ...patch } : truck)),
        })),
      removeTruck: (id) =>
        set((s) => ({
          trucks: s.trucks.filter((truck) => truck.id !== id),
          tires: s.tires.filter((tire) => tire.truckId !== id),
          oils: s.oils.filter((oil) => oil.truckId !== id),
        })),
      addTire: (input) => {
        const id = uid();
        set((s) => ({
          tires: [{ ...input, id }, ...s.tires],
          trucks: bump(s.trucks, input.truckId, input.mileage),
        }));
        return id;
      },
      updateTire: (id, patch) =>
        set((s) => {
          const tires = s.tires.map((tire) => (tire.id === id ? { ...tire, ...patch } : tire));
          const next = tires.find((tire) => tire.id === id);
          return {
            tires,
            trucks: next ? bump(s.trucks, next.truckId, next.mileage) : s.trucks,
          };
        }),
      removeTire: (id) => set((s) => ({ tires: s.tires.filter((tire) => tire.id !== id) })),
      addOil: (input) => {
        const id = uid();
        set((s) => ({
          oils: [{ ...input, id }, ...s.oils],
          trucks: bump(s.trucks, input.truckId, input.mileage),
        }));
        return id;
      },
      updateOil: (id, patch) =>
        set((s) => {
          const oils = s.oils.map((oil) => (oil.id === id ? { ...oil, ...patch } : oil));
          const next = oils.find((oil) => oil.id === id);
          return {
            oils,
            trucks: next ? bump(s.trucks, next.truckId, next.mileage) : s.trucks,
          };
        }),
      removeOil: (id) => set((s) => ({ oils: s.oils.filter((oil) => oil.id !== id) })),
      importBackup: (data) => set({ trucks: data.trucks, tires: data.tires, oils: data.oils }),
      resetDemo: () => set(demo()),
    }),
    { name: "axlehouse-v1", skipHydration: true },
  ),
);
