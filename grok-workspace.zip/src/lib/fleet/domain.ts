import { differenceInCalendarDays, format, parseISO, startOfMonth, subMonths } from "date-fns";
import { miles, shortDate } from "@/lib/fleet/format";
import type { OilChange, TireEvent, Truck, TruckStatus } from "@/lib/fleet/types";

export type MonthPoint = { key: string; label: string; tires: number; oil: number };

export type OilReadout = {
  tone: "good" | "warn" | "bad";
  label: string;
  detail: string;
};

const STATUS_RANK: Record<TruckStatus, number> = {
  "in-service": 0,
  shop: 1,
  parked: 2,
};

export function bySpot(a: Truck, b: Truck) {
  return a.spot.localeCompare(b.spot, undefined, { numeric: true, sensitivity: "base" });
}

export function byNumber(a: Truck, b: Truck) {
  return a.number.localeCompare(b.number, undefined, { numeric: true, sensitivity: "base" });
}

export function truckLabel(truck: Truck | undefined) {
  return truck ? `Truck ${truck.number}` : "Unknown truck";
}

export function unitLine(truck: Truck) {
  return [truck.year, truck.make, truck.model].filter(Boolean).join(" ");
}

export function engineLine(truck: Truck) {
  return [truck.engineSize, truck.engineDetails].filter(Boolean).join(" · ");
}

export function haystack(parts: Array<string | number | undefined>) {
  return parts.join(" ").toLowerCase();
}

export function includesQuery(hay: string, query: string) {
  const q = query.trim().toLowerCase();
  if (!q) return true;
  return hay.includes(q);
}

export function truckHay(truck: Truck) {
  return haystack([
    truck.number,
    `truck ${truck.number}`,
    truck.vin,
    truck.plate,
    truck.spot,
    `spot ${truck.spot}`,
    truck.year,
    truck.make,
    truck.model,
    truck.engineSize,
    truck.engineDetails,
    truck.notes,
    truck.status,
  ]);
}

export function latestOil(oils: OilChange[], truckId: string) {
  return oils
    .filter((o) => o.truckId === truckId)
    .sort((a, b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id))[0];
}

export function oilStatus(truck: Truck, oils: OilChange[], today = new Date()): OilReadout {
  const latest = latestOil(oils, truck.id);
  if (!latest) {
    return { tone: "warn", label: "No oil record", detail: "Log the last change" };
  }

  const milesLeft = latest.nextDueMileage > 0 ? latest.nextDueMileage - truck.odometer : null;
  let daysLeft: number | null = null;
  if (latest.nextDueDate) {
    const due = parseISO(latest.nextDueDate);
    if (!Number.isNaN(due.getTime())) daysLeft = differenceInCalendarDays(due, today);
  }

  const parts: string[] = [];
  if (milesLeft !== null) {
    parts.push(milesLeft >= 0 ? `${miles(milesLeft)} left` : `${miles(Math.abs(milesLeft))} past`);
  }
  if (latest.nextDueDate) {
    parts.push(daysLeft !== null && daysLeft < 0 ? `was due ${shortDate(latest.nextDueDate)}` : `due ${shortDate(latest.nextDueDate)}`);
  }

  const detail = parts.join(" · ");
  const mileBad = milesLeft !== null && milesLeft <= 0;
  const dateBad = daysLeft !== null && daysLeft < 0;
  const mileSoon = milesLeft !== null && milesLeft > 0 && milesLeft <= 2000;
  const dateSoon = daysLeft !== null && daysLeft >= 0 && daysLeft <= 21;

  if (mileBad || dateBad) return { tone: "bad", label: "Overdue", detail };
  if (mileSoon || dateSoon) return { tone: "warn", label: "Due soon", detail };
  return { tone: "good", label: "On schedule", detail };
}

export function attentionRank(tone: OilReadout["tone"]) {
  if (tone === "bad") return 0;
  if (tone === "warn") return 1;
  return 2;
}

export function statusRank(status: TruckStatus) {
  return STATUS_RANK[status];
}

export function sharedSpotIds(trucks: Truck[]) {
  const groups = new Map<string, string[]>();
  for (const truck of trucks) {
    const key = truck.spot.trim().toLowerCase();
    if (!key) continue;
    const list = groups.get(key) ?? [];
    list.push(truck.id);
    groups.set(key, list);
  }
  const shared = new Set<string>();
  for (const ids of groups.values()) {
    if (ids.length > 1) ids.forEach((id) => shared.add(id));
  }
  return shared;
}

export function sumInYear(tires: TireEvent[], oils: OilChange[], year: number) {
  const prefix = `${year}-`;
  const tire = tires.filter((t) => t.date.startsWith(prefix)).reduce((sum, t) => sum + t.fee, 0);
  const oil = oils.filter((o) => o.date.startsWith(prefix)).reduce((sum, o) => sum + o.fee, 0);
  return { tire, oil, total: tire + oil };
}

export function spendForTruck(tires: TireEvent[], oils: OilChange[], truckId: string) {
  const tire = tires.filter((t) => t.truckId === truckId).reduce((sum, t) => sum + t.fee, 0);
  const oil = oils.filter((o) => o.truckId === truckId).reduce((sum, o) => sum + o.fee, 0);
  return { tire, oil, total: tire + oil };
}

export function monthlySpend(tires: TireEvent[], oils: OilChange[], count = 6, from = new Date()): MonthPoint[] {
  const start = startOfMonth(from);
  const points: MonthPoint[] = [];
  for (let i = count - 1; i >= 0; i -= 1) {
    const d = subMonths(start, i);
    const key = format(d, "yyyy-MM");
    points.push({
      key,
      label: format(d, "MMM"),
      tires: tires.filter((t) => t.date.startsWith(key)).reduce((sum, t) => sum + t.fee, 0),
      oil: oils.filter((o) => o.date.startsWith(key)).reduce((sum, o) => sum + o.fee, 0),
    });
  }
  return points;
}

export function tireDetail(event: TireEvent) {
  const spec = [event.brand, event.size].filter(Boolean).join(" ");
  return [event.action, event.position, spec].filter(Boolean).join(" · ");
}

export function oilDetail(event: OilChange) {
  return [event.oilType, event.quantity, event.vendor].filter(Boolean).join(" · ");
}
